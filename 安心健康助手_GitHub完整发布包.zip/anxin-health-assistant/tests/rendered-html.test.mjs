import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

async function render(pathname = "/") {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);

  return worker.fetch(
    new Request(`http://localhost${pathname}`, {
      headers: { accept: "text/html" },
    }),
    {
      ASSETS: {
        fetch: async () => new Response("Not found", { status: 404 }),
      },
    },
    {
      waitUntil() {},
      passThroughOnException() {},
    },
  );
}

test("服务端可渲染入口与深层页面", async () => {
  for (const pathname of [
    "/",
    "/home",
    "/health/add",
    "/reports",
    "/reports/add",
    "/medications/today",
    "/settings/notifications",
    "/privacy",
  ]) {
    const response = await render(pathname);
    assert.equal(response.status, 200, pathname);
    assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);
    const html = await response.text();
    assert.match(html, /<html lang="zh-CN">/);
    assert.match(html, /<title>安心健康助手<\/title>/);
    assert.doesNotMatch(html, /codex-preview|Your site is taking shape/);
  }
});

test("PWA 清单包含安装信息和两种尺寸图标", async () => {
  const manifest = JSON.parse(
    await readFile(new URL("../public/manifest.webmanifest", import.meta.url), "utf8"),
  );
  assert.equal(manifest.name, "安心健康助手");
  assert.equal(manifest.display, "standalone");
  assert.equal(manifest.start_url, "/home");
  assert.deepEqual(
    manifest.icons.map((icon) => icon.sizes),
    ["192x192", "512x512"],
  );
});

test("适老化尺寸、安全声明和提醒限制保持在代码中", async () => {
  const [css, health, notifications, store, dialog] = await Promise.all([
    readFile(new URL("../app/globals.css", import.meta.url), "utf8"),
    readFile(new URL("../features/Health.tsx", import.meta.url), "utf8"),
    readFile(new URL("../features/Account.tsx", import.meta.url), "utf8"),
    readFile(new URL("../lib/store.tsx", import.meta.url), "utf8"),
    readFile(new URL("../components/ui.tsx", import.meta.url), "utf8"),
  ]);

  assert.match(css, /--body-size:\s*18px/);
  assert.match(css, /\.button\s*\{[\s\S]*min-height:\s*50px/);
  assert.match(css, /overflow-x:\s*hidden/);
  assert.match(css, /prefers-reduced-motion/);
  assert.match(health, /不提供疾病诊断/);
  assert.match(health, /当地紧急医疗服务/);
  assert.match(notifications, /浏览器提醒的重要限制/);
  assert.match(notifications, /不能保证准时提醒/);
  assert.match(store, /localStorage/);
  assert.match(dialog, /role="alertdialog"/);
  assert.match(dialog, /确认删除/);
});

test("体检报告趋势保留原始数据并明确分析边界", async () => {
  const [reports, analysis, types, schema] = await Promise.all([
    readFile(new URL("../features/ExamReports.tsx", import.meta.url), "utf8"),
    readFile(new URL("../lib/exam-analysis.ts", import.meta.url), "utf8"),
    readFile(new URL("../lib/types.ts", import.meta.url), "utf8"),
    readFile(new URL("../supabase/schema.sql", import.meta.url), "utf8"),
  ]);

  assert.match(reports, /健康指标 K 线/);
  assert.match(reports, /保存并生成分析/);
  assert.match(reports, /这不是医学诊断/);
  assert.match(reports, /不要仅凭自动分析自行停药/);
  assert.match(analysis, /报告参考范围/);
  assert.match(analysis, /不要自行停药、加药或改变剂量/);
  assert.match(types, /examinationReports: ExaminationReport\[\]/);
  assert.match(schema, /create table if not exists public\.examination_reports/);
  assert.match(schema, /examination_reports_user_date_idx/);
});
