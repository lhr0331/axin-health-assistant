import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "安心健康助手",
    template: "%s | 安心健康助手",
  },
  description:
    "面向中老年用户的个人健康记录、用药提醒、饮食和每日备忘应用。",
  applicationName: "安心健康助手",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    title: "安心健康",
    statusBarStyle: "default",
  },
  formatDetection: {
    telephone: false,
  },
  openGraph: {
    type: "website",
    locale: "zh_CN",
    title: "安心健康助手",
    description: "每天记一点，健康更安心",
    images: [{ url: "/og.png", width: 1200, height: 630, alt: "安心健康助手" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "安心健康助手",
    description: "每天记一点，健康更安心",
    images: ["/og.png"],
  },
  icons: {
    icon: "/icon-192.png",
    apple: "/icon-192.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body>{children}</body>
    </html>
  );
}
