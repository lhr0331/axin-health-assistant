import { HealthApp } from "@/components/HealthApp";

export default function AppRoute() {
  return <HealthApp />;
}
