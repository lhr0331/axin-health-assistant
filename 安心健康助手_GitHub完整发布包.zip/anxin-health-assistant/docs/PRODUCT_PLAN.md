# 安心健康助手：第一阶段产品与技术规划

## 1. 产品功能结构

- 今日：首页、今日用药、今日饮食、今日身体状态、今日备忘。
- 健康：身体记录、历史记录、疾病档案；血压、血糖、体重等后续模块放在相同领域下。
- 用药：药品、多个服用时间、今日任务、服药日志、提醒。
- 饮食：三餐、加餐、饮水、可选照片。
- 我的：资料、字体、通知、声音、导出、隐私、帮助。
- 账户：第一阶段为无需注册的设备演示模式；手机号验证码和云同步保留适配层。

## 2. 页面结构

应用包含登录、四步引导、首页、健康中心、身体记录表单与历史、疾病档案、药品列表与表单、今日用药与历史、备忘列表与表单、饮食列表与表单、个人资料、设置、通知设置、帮助、隐私及 404 页面。手机使用五项底部导航，桌面使用同名左侧导航。

## 3. 关键用户流程

1. 第一次进入：演示模式 → 四步引导 → 解释通知用途 → 用户主动授权 → 首页。
2. 记录身体：首页快捷按钮 → 大按钮选择状态与症状 → 保存反馈 → 历史列表。
3. 添加药品：药品管理 → 填写用量与多个时间 → 开启提醒 → 今日任务自动出现。
4. 完成服药：今日用药 → 已服用、稍后提醒或跳过 → 记录实际时间 → 进度更新。
5. 记录饮食/备忘：首页快捷按钮 → 简化表单 → 保存反馈 → 当日列表。

## 4. 技术架构

- 前端：Vinext/Next.js 兼容路由、React 19、TypeScript 严格模式、Tailwind CSS 基础能力、适老化设计令牌、Lucide React。
- 表单：受控组件与共享 Field/Choice 组件；Zod 和 React Hook Form 已安装，供后续云端表单和复杂校验迁移。
- PWA：Web App Manifest、Service Worker、主屏幕图标、缓存式应用壳。
- 数据：演示模式使用统一 StoreProvider 和浏览器 localStorage；正式账户使用 `HealthDataRepository` 适配 Supabase。
- 后端：`supabase/schema.sql` 提供 PostgreSQL 表、索引、RLS 和用户自动建档逻辑。
- 文件：演示模式只保存图片文件名，不上传；正式模式使用私有对象存储桶和签名 URL。

## 5. 数据库设计

核心表为 users/auth.users、user_profiles、health_records、diseases、medications、medication_schedules、medication_logs、reminders、memos、meal_records、notification_logs、user_settings、audit_logs。所有业务表包含 user_id、created_at、updated_at，重要记录使用 deleted_at 软删除。每张表都启用 RLS，并用 `auth.uid() = user_id` 限制读写。

## 6. 文件目录结构

```text
app/                 页面入口、全局样式
components/          公共组件、应用壳、路由
features/            首页、健康、用药、日常、账户领域页面
lib/                 类型、演示数据、日期、数据仓储接口、状态层
public/              PWA 清单、Service Worker、应用图标
supabase/            PostgreSQL 初始化与 RLS 脚本
docs/                产品规划与架构说明
```

## 7. 提醒功能实现方案

- 应用打开时每 30 秒检查到期任务，以日期、药品和时间组成去重键。
- 到期同时显示应用内高对比提醒；权限允许时调用 Notification API。
- 通知使用 tag 避免重复，发送键保存在 notificationLogs。
- 稍后提醒界面支持 10、20、30、60 分钟；第一阶段保持应用内体验。
- 浏览器被彻底关闭时不能承诺可靠后台定时。正式版本应由服务端调度器读取 reminders，再通过短信、微信服务通知或原生推送网关发送。

## 8. 隐私与安全

- 生产环境必须使用 HTTPS、Supabase Auth、RLS、私有存储桶和短时签名 URL。
- 前端只允许匿名公钥，管理员密钥只保存在受保护的服务端环境。
- 健康数据不接入第三方行为分析服务；敏感日志不记录正文。
- 删除先软删除，账户级删除使用可审计的服务端流程。
- 对导出、上传、账户删除和紧急联系人用途提供明确说明。
- 产品不自动诊断、不评价药效、不更改医生方案。
