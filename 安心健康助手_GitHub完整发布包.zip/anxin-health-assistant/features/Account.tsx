"use client";

import {
  Accessibility,
  Bell,
  BellOff,
  CheckCircle2,
  ChevronRight,
  CircleHelp,
  Database,
  Download,
  LogOut,
  RotateCcw,
  Settings as SettingsIcon,
  ShieldCheck,
  Smartphone,
  UserRound,
  Volume2,
} from "lucide-react";
import { useState } from "react";
import { navigate } from "@/components/AppShell";
import {
  Button,
  Card,
  ConfirmDialog,
  Field,
  Input,
  PageHeader,
  Select,
  Textarea,
  useToast,
} from "@/components/ui";
import { useStore } from "@/lib/store";

const profileLinks = [
  {
    href: "/profile/edit",
    label: "个人资料",
    description: "姓名、紧急联系人和过敏信息",
    icon: UserRound,
  },
  {
    href: "/settings",
    label: "字体与设置",
    description: "字体大小、提醒声音和数据管理",
    icon: SettingsIcon,
  },
  {
    href: "/settings/notifications",
    label: "通知设置",
    description: "检查并开启服药提醒",
    icon: Bell,
  },
  {
    href: "/help",
    label: "帮助说明",
    description: "了解记录、提醒和安装方法",
    icon: CircleHelp,
  },
  {
    href: "/privacy",
    label: "隐私政策",
    description: "了解健康数据如何保存和使用",
    icon: ShieldCheck,
  },
];

export function Profile() {
  const { data } = useStore();
  return (
    <>
      <PageHeader title="我的" description="管理个人资料、通知和隐私设置" />
      <Card className="profile-summary">
        <span className="profile-avatar">
          <UserRound aria-hidden="true" />
        </span>
        <div>
          <h2>{data.profile.name || "安心用户"}</h2>
          <p>当前为演示模式，数据保存在这台设备的浏览器中。</p>
        </div>
        <span className="demo-badge">演示模式</span>
      </Card>
      <div className="settings-list">
        {profileLinks.map((item) => {
          const Icon = item.icon;
          return (
            <a key={item.href} href={item.href} data-nav>
              <span>
                <Icon aria-hidden="true" />
              </span>
              <div>
                <strong>{item.label}</strong>
                <small>{item.description}</small>
              </div>
              <ChevronRight aria-hidden="true" />
            </a>
          );
        })}
        <button type="button" onClick={() => navigate("/")}>
          <span>
            <LogOut aria-hidden="true" />
          </span>
          <div>
            <strong>退出演示模式</strong>
            <small>返回登录和体验入口</small>
          </div>
          <ChevronRight aria-hidden="true" />
        </button>
      </div>
    </>
  );
}

export function ProfileForm() {
  const { data, update } = useStore();
  const { showToast } = useToast();
  const [form, setForm] = useState(data.profile);
  return (
    <>
      <PageHeader
        title="个人资料"
        description="这些信息仅用于个人健康记录和紧急联系"
        backHref="/profile"
      />
      <Card className="privacy-inline">
        <ShieldCheck aria-hidden="true" />
        <p>
          演示模式不会上传这些信息。正式账户模式接入后，将通过身份验证和行级权限隔离每位用户的数据。
        </p>
      </Card>
      <Card>
        <form
          className="form-stack"
          onSubmit={(event) => {
            event.preventDefault();
            update((current) => ({ ...current, profile: form }));
            showToast("个人资料已保存");
          }}
        >
          <div className="form-grid">
            <Field label="姓名或昵称">
              <Input
                value={form.name}
                onChange={(event) =>
                  setForm({ ...form, name: event.target.value })
                }
              />
            </Field>
            <Field label="性别">
              <Select
                value={form.gender}
                onChange={(event) =>
                  setForm({ ...form, gender: event.target.value })
                }
              >
                <option value="">暂不填写</option>
                <option>男</option>
                <option>女</option>
                <option>其他</option>
              </Select>
            </Field>
            <Field label="出生日期">
              <Input
                type="date"
                value={form.birthDate}
                onChange={(event) =>
                  setForm({ ...form, birthDate: event.target.value })
                }
              />
            </Field>
            <Field label="联系电话">
              <Input
                type="tel"
                inputMode="tel"
                value={form.phone}
                onChange={(event) =>
                  setForm({ ...form, phone: event.target.value })
                }
              />
            </Field>
            <Field label="紧急联系人姓名">
              <Input
                value={form.emergencyName}
                onChange={(event) =>
                  setForm({ ...form, emergencyName: event.target.value })
                }
              />
            </Field>
            <Field label="紧急联系人电话">
              <Input
                type="tel"
                inputMode="tel"
                value={form.emergencyPhone}
                onChange={(event) =>
                  setForm({ ...form, emergencyPhone: event.target.value })
                }
              />
            </Field>
            <Field label="血型">
              <Select
                value={form.bloodType}
                onChange={(event) =>
                  setForm({ ...form, bloodType: event.target.value })
                }
              >
                <option value="">暂不填写</option>
                {["A", "B", "AB", "O", "不清楚"].map((item) => (
                  <option key={item}>{item}</option>
                ))}
              </Select>
            </Field>
            <Field label="过敏信息">
              <Input
                value={form.allergies}
                placeholder="例如：青霉素过敏"
                onChange={(event) =>
                  setForm({ ...form, allergies: event.target.value })
                }
              />
            </Field>
          </div>
          <Field label="其他备注">
            <Textarea
              value={form.note}
              onChange={(event) => setForm({ ...form, note: event.target.value })}
            />
          </Field>
          <Button type="submit" icon={UserRound}>
            保存个人资料
          </Button>
        </form>
      </Card>
    </>
  );
}

export function SettingsPage() {
  const { data, updateSettings, reset, exportData } = useStore();
  const { showToast } = useToast();
  const [resetOpen, setResetOpen] = useState(false);
  return (
    <>
      <PageHeader
        title="设置"
        description="调整字体、声音和数据管理选项"
        backHref="/profile"
      />
      <Card className="setting-section">
        <h2>
          <Accessibility aria-hidden="true" />
          显示与操作
        </h2>
        <label className="toggle-row">
          <span>
            <strong>大字体模式</strong>
            <small>正文和按钮文字会更大，更容易阅读</small>
          </span>
          <input
            type="checkbox"
            checked={data.settings.largeText}
            onChange={(event) =>
              updateSettings({ largeText: event.target.checked })
            }
          />
        </label>
      </Card>
      <Card className="setting-section">
        <h2>
          <Volume2 aria-hidden="true" />
          提醒设置
        </h2>
        <label className="toggle-row">
          <span>
            <strong>提醒声音</strong>
            <small>受浏览器和手机系统静音设置影响</small>
          </span>
          <input
            type="checkbox"
            checked={data.settings.reminderSound}
            onChange={(event) =>
              updateSettings({ reminderSound: event.target.checked })
            }
          />
        </label>
        <Button
          variant="secondary"
          icon={Bell}
          onClick={() => navigate("/settings/notifications")}
        >
          打开通知设置
        </Button>
      </Card>
      <Card className="setting-section">
        <h2>
          <Database aria-hidden="true" />
          演示数据
        </h2>
        <p>
          演示数据保存在当前浏览器。你可以导出 JSON 备份，也可以恢复初始虚拟数据。
        </p>
        <div className="button-row">
          <Button variant="secondary" icon={Download} onClick={exportData}>
            导出我的数据
          </Button>
          <Button
            variant="danger"
            icon={RotateCcw}
            onClick={() => setResetOpen(true)}
          >
            重置演示数据
          </Button>
        </div>
      </Card>
      <ConfirmDialog
        open={resetOpen}
        title="确认重置全部演示数据？"
        description="你添加和修改的本地记录会被清除，并恢复为初始虚拟数据。建议先导出备份。"
        confirmText="确认重置"
        onCancel={() => setResetOpen(false)}
        onConfirm={() => {
          reset();
          setResetOpen(false);
          showToast("演示数据已重置");
        }}
      />
    </>
  );
}

export function NotificationSettings() {
  const { data, updateSettings } = useStore();
  const { showToast } = useToast();
  const supported = typeof window !== "undefined" && "Notification" in window;
  const permission = supported ? Notification.permission : "unsupported";

  const request = async () => {
    if (!supported) {
      showToast("当前浏览器不支持系统通知", "error");
      return;
    }
    const result = await Notification.requestPermission();
    updateSettings({ notificationsEnabled: result === "granted" });
    showToast(
      result === "granted"
        ? "浏览器通知已开启"
        : result === "denied"
          ? "通知权限未开启，请按页面说明前往浏览器设置"
          : "暂未开启通知",
      result === "granted" ? "success" : "error",
    );
  };

  return (
    <>
      <PageHeader
        title="通知设置"
        description="先了解用途，再决定是否允许发送服药提醒"
        backHref="/settings"
      />
      <Card className="permission-card">
        <span className={`permission-icon ${permission === "granted" ? "allowed" : ""}`}>
          {permission === "granted" ? (
            <CheckCircle2 aria-hidden="true" />
          ) : (
            <BellOff aria-hidden="true" />
          )}
        </span>
        <div>
          <span className="card-kicker">当前状态</span>
          <h2>
            {permission === "granted"
              ? "浏览器通知已允许"
              : permission === "denied"
                ? "浏览器通知已关闭"
                : permission === "unsupported"
                  ? "当前浏览器不支持通知"
                  : "尚未选择通知权限"}
          </h2>
          <p>
            开启后，应用在浏览器允许的情况下发送药品名称、用量和服用要求。
          </p>
        </div>
      </Card>
      {permission === "denied" ? (
        <Card className="instruction-card">
          <h2>如何重新开启</h2>
          <ol>
            <li>打开浏览器的网站设置或地址栏旁的锁形图标。</li>
            <li>找到“通知”，改为“允许”。</li>
            <li>返回本页面并刷新。</li>
          </ol>
        </Card>
      ) : null}
      <Card className="notification-limits">
        <Smartphone aria-hidden="true" />
        <div>
          <h2>浏览器提醒的重要限制</h2>
          <p>
            手机系统可能限制后台运行。浏览器被彻底关闭、系统省电、通知被静音或
            iPhone 未将 PWA 添加到主屏幕时，后台通知可能延迟或不出现。应用内提醒仍会在打开应用时检查。
          </p>
          <p>
            因此请不要把浏览器通知作为紧急医疗提醒的唯一方式。后续可接入短信、微信服务通知或原生 App 推送。
          </p>
        </div>
      </Card>
      <div className="button-row">
        {permission !== "granted" ? (
          <Button icon={Bell} onClick={request}>
            允许发送提醒
          </Button>
        ) : (
          <Button
            variant="secondary"
            onClick={() => {
              new Notification("安心健康助手测试提醒", {
                body: "通知功能可以正常使用。请注意，系统仍可能限制后台通知。",
              });
              showToast("测试提醒已发送");
            }}
          >
            发送测试提醒
          </Button>
        )}
        <label className="toggle-row inline-toggle">
          <span>
            <strong>在应用中启用提醒</strong>
          </span>
          <input
            type="checkbox"
            disabled={permission !== "granted"}
            checked={data.settings.notificationsEnabled}
            onChange={(event) =>
              updateSettings({ notificationsEnabled: event.target.checked })
            }
          />
        </label>
      </div>
    </>
  );
}

export function Help() {
  return (
    <>
      <PageHeader title="帮助说明" description="常见操作和问题说明" backHref="/profile" />
      <div className="help-list">
        {[
          [
            "如何添加到手机桌面？",
            "iPhone Safari 中点击分享按钮，再选择“添加到主屏幕”。Android Chrome 中打开浏览器菜单，选择“安装应用”或“添加到主屏幕”。",
          ],
          [
            "为什么没有收到服药提醒？",
            "请检查浏览器通知权限、手机静音和省电设置。浏览器后台能力有限，彻底关闭后不能保证准时提醒。",
          ],
          [
            "记录会上传到哪里？",
            "当前演示模式只保存在此浏览器，不会上传。清除浏览器数据会导致记录丢失，请先导出备份。",
          ],
          [
            "身体不舒服怎么办？",
            "本应用不提供诊断。如症状严重或持续，请及时联系家人、医生或当地紧急医疗服务。",
          ],
        ].map(([title, content]) => (
          <details key={title}>
            <summary>{title}</summary>
            <p>{content}</p>
          </details>
        ))}
      </div>
    </>
  );
}

export function Privacy() {
  return (
    <>
      <PageHeader title="隐私政策" description="了解我们如何保护健康信息" backHref="/profile" />
      <article className="legal">
        <h2>1. 当前演示模式</h2>
        <p>
          健康记录、药品、备忘和饮食数据保存在你的浏览器本地。应用不会主动将这些数据发送给第三方分析服务。清除浏览器数据可能导致记录丢失。
        </p>
        <h2>2. 信息用途</h2>
        <p>
          个人资料用于显示称呼、保存紧急联系人和帮助你整理个人健康记录。通知权限只用于发送你主动设置的服药或备忘提醒。
        </p>
        <h2>3. 正式账户模式</h2>
        <p>
          后续云同步将采用身份验证、HTTPS、用户数据隔离、数据库行级权限、最小化文件访问和操作日志。管理员密钥不会放在前端。
        </p>
        <h2>4. 数据权利</h2>
        <p>
          你可以导出数据、删除单条记录、重置演示数据。正式账户模式将提供账户数据删除和找回能力。
        </p>
        <h2>5. 医疗声明</h2>
        <p>
          本应用用于帮助用户记录个人健康信息，不提供医学诊断。如身体不适，请及时咨询专业医生。
        </p>
      </article>
    </>
  );
}
