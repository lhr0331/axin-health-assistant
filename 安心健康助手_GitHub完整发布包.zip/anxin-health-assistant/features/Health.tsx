"use client";

import {
  AlertTriangle,
  BarChart3,
  CalendarDays,
  ChevronRight,
  FileHeart,
  History,
  Pencil,
  Plus,
  Stethoscope,
  Trash2,
} from "lucide-react";
import { useMemo, useState } from "react";
import { navigate } from "@/components/AppShell";
import {
  Button,
  Card,
  ChoiceGroup,
  ConfirmDialog,
  EmptyState,
  Field,
  Input,
  PageHeader,
  Select,
  StatusBadge,
  Textarea,
  useToast,
} from "@/components/ui";
import { isoDate, timeNow, uid } from "@/lib/date";
import { getAppSearchParams } from "@/lib/app-location";
import { useStore } from "@/lib/store";
import type { Disease, HealthRecord } from "@/lib/types";

const symptoms = [
  "头晕",
  "头痛",
  "咳嗽",
  "胸闷",
  "心慌",
  "恶心",
  "腹痛",
  "腹泻",
  "乏力",
  "失眠",
  "食欲不振",
  "其他",
];

export function HealthHub() {
  const { data } = useStore();
  const todayRecord = data.healthRecords.find(
    (item) => item.date === isoDate() && !item.deletedAt,
  );
  const activeDiseases = data.diseases.filter((item) => !item.deletedAt);
  const activeReports = data.examinationReports.filter(
    (item) => !item.deletedAt,
  );
  return (
    <>
      <PageHeader
        title="健康"
        description="记录身体感受，管理自己的健康档案"
        action={
          <Button icon={Plus} onClick={() => navigate("/health/add")}>
            记录身体状况
          </Button>
        }
      />
      <div className="feature-grid">
        <Card className="feature-card">
          <span className="feature-icon">
            <Stethoscope aria-hidden="true" />
          </span>
          <div>
            <h2>今日身体状况</h2>
            <p>
              {todayRecord
                ? `已记录：${todayRecord.overall}，${todayRecord.symptoms.join("、") || "无明显症状"}`
                : "今天还没有记录，花一分钟记一下吧。"}
            </p>
          </div>
          <a href="/health/add" data-nav>
            {todayRecord ? "查看或修改" : "现在记录"}
            <ChevronRight aria-hidden="true" />
          </a>
        </Card>
        <Card className="feature-card">
          <span className="feature-icon">
            <History aria-hidden="true" />
          </span>
          <div>
            <h2>身体记录历史</h2>
            <p>已有 {data.healthRecords.filter((item) => !item.deletedAt).length} 条记录</p>
          </div>
          <a href="/health/history" data-nav>
            按日期查看
            <ChevronRight aria-hidden="true" />
          </a>
        </Card>
        <Card className="feature-card">
          <span className="feature-icon">
            <FileHeart aria-hidden="true" />
          </span>
          <div>
            <h2>疾病档案</h2>
            <p>正在管理 {activeDiseases.length} 份疾病档案</p>
          </div>
          <a href="/diseases" data-nav>
            查看疾病档案
            <ChevronRight aria-hidden="true" />
          </a>
        </Card>
        <Card className="feature-card">
          <span className="feature-icon">
            <BarChart3 aria-hidden="true" />
          </span>
          <div>
            <h2>体检报告趋势</h2>
            <p>
              已保存 {activeReports.length} 份报告，可查看指标 K 线和实时分析
            </p>
          </div>
          <a href="/reports" data-nav>
            查看体检趋势
            <ChevronRight aria-hidden="true" />
          </a>
        </Card>
      </div>
      <Card className="safety-note">
        <AlertTriangle aria-hidden="true" />
        <div>
          <h2>重要说明</h2>
          <p>
            本应用只帮助记录，不提供疾病诊断，也不会自动修改医生给出的治疗或用药方案。
          </p>
        </div>
      </Card>
    </>
  );
}

export function HealthForm() {
  const { data, update } = useStore();
  const queryId =
    typeof window === "undefined"
      ? null
      : getAppSearchParams().get("id");
  const existing = data.healthRecords.find(
    (item) =>
      !item.deletedAt &&
      (queryId ? item.id === queryId : item.date === isoDate()),
  );
  const [form, setForm] = useState<HealthRecord>(
    existing || {
      id: uid(),
      date: isoDate(),
      time: timeNow(),
      overall: "正常",
      spirit: "一般",
      sleep: "一般",
      pain: "无",
      painLocation: "",
      symptoms: [],
      note: "",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
  );
  const [otherSymptom, setOtherSymptom] = useState("");
  const { showToast } = useToast();
  const serious = useMemo(
    () =>
      [...form.symptoms, otherSymptom].some((item) =>
        ["胸痛", "呼吸困难", "昏厥"].some((warning) => item.includes(warning)),
      ),
    [form.symptoms, otherSymptom],
  );

  const save = () => {
    const next = {
      ...form,
      symptoms:
        form.symptoms.includes("其他") && otherSymptom.trim()
          ? [...form.symptoms.filter((item) => item !== "其他"), otherSymptom.trim()]
          : form.symptoms,
      updatedAt: new Date().toISOString(),
    };
    update((current) => ({
      ...current,
      healthRecords: [
        ...current.healthRecords.filter((item) => item.id !== next.id),
        next,
      ],
    }));
    showToast("身体记录已保存");
    navigate("/health/history");
  };

  return (
    <>
      <PageHeader
        title={existing ? "查看或修改今日记录" : "记录身体状况"}
        description="按自己的真实感受选择，不需要使用专业医学术语。"
        backHref="/health"
      />
      {serious ? (
        <div className="urgent-alert" role="alert">
          <AlertTriangle aria-hidden="true" />
          <div>
            <strong>请注意身体安全</strong>
            <p>
              如症状严重或持续，请及时联系家人、医生或当地紧急医疗服务。
            </p>
          </div>
        </div>
      ) : null}
      <Card>
        <form
          className="form-stack"
          onSubmit={(event) => {
            event.preventDefault();
            save();
          }}
        >
          <div className="form-grid">
            <Field label="日期">
              <Input
                type="date"
                value={form.date}
                onChange={(event) =>
                  setForm({ ...form, date: event.target.value })
                }
                required
              />
            </Field>
            <Field label="时间">
              <Input
                type="time"
                value={form.time}
                onChange={(event) =>
                  setForm({ ...form, time: event.target.value })
                }
                required
              />
            </Field>
          </div>
          <Field label="今日整体状态">
            <ChoiceGroup
              options={["很好", "正常", "不太舒服", "很不舒服"]}
              value={form.overall}
              onChange={(value) =>
                setForm({ ...form, overall: value as HealthRecord["overall"] })
              }
              ariaLabel="选择今日整体状态"
            />
          </Field>
          <div className="form-grid">
            <Field label="精神状态">
              <Select
                value={form.spirit}
                onChange={(event) =>
                  setForm({ ...form, spirit: event.target.value })
                }
              >
                {["很好", "一般", "有些疲倦", "很疲倦"].map((item) => (
                  <option key={item}>{item}</option>
                ))}
              </Select>
            </Field>
            <Field label="睡眠情况">
              <Select
                value={form.sleep}
                onChange={(event) =>
                  setForm({ ...form, sleep: event.target.value })
                }
              >
                {["很好", "一般", "睡得不好", "几乎没睡"].map((item) => (
                  <option key={item}>{item}</option>
                ))}
              </Select>
            </Field>
            <Field label="疼痛情况">
              <Select
                value={form.pain}
                onChange={(event) =>
                  setForm({ ...form, pain: event.target.value })
                }
              >
                {["无", "轻微", "中等", "严重"].map((item) => (
                  <option key={item}>{item}</option>
                ))}
              </Select>
            </Field>
            <Field label="疼痛位置" hint="没有疼痛可以不填">
              <Input
                value={form.painLocation}
                placeholder="例如：左膝、腰部"
                onChange={(event) =>
                  setForm({ ...form, painLocation: event.target.value })
                }
              />
            </Field>
          </div>
          <Field label="常见症状" hint="可以选择多个">
            <ChoiceGroup
              options={symptoms}
              value={form.symptoms}
              onChange={(value) =>
                setForm({ ...form, symptoms: value as string[] })
              }
              multiple
              ariaLabel="选择症状"
            />
          </Field>
          {form.symptoms.includes("其他") ? (
            <Field label="其他症状">
              <Input
                value={otherSymptom}
                placeholder="请用简单文字描述"
                onChange={(event) => setOtherSymptom(event.target.value)}
              />
            </Field>
          ) : null}
          <Field label="备注" hint="可不填">
            <Textarea
              value={form.note}
              placeholder="还有什么想记录的？"
              onChange={(event) => setForm({ ...form, note: event.target.value })}
            />
          </Field>
          <div className="sticky-form-actions">
            <Button type="submit" icon={Stethoscope}>
              保存身体记录
            </Button>
            <Button
              type="button"
              variant="secondary"
              onClick={() => navigate("/health")}
            >
              取消
            </Button>
          </div>
        </form>
      </Card>
    </>
  );
}

export function HealthHistory() {
  const { data, update } = useStore();
  const { showToast } = useToast();
  const [date, setDate] = useState("");
  const [deleting, setDeleting] = useState<HealthRecord | null>(null);
  const records = data.healthRecords
    .filter((item) => !item.deletedAt && (!date || item.date === date))
    .sort((a, b) => `${b.date}${b.time}`.localeCompare(`${a.date}${a.time}`));
  return (
    <>
      <PageHeader
        title="身体记录历史"
        description="按日期查看过去的身体情况"
        backHref="/health"
        action={
          <Button icon={Plus} onClick={() => navigate("/health/add")}>
            新增记录
          </Button>
        }
      />
      <Card className="filter-card">
        <Field label="选择日期">
          <Input
            type="date"
            value={date}
            onChange={(event) => setDate(event.target.value)}
          />
        </Field>
        {date ? (
          <Button variant="quiet" onClick={() => setDate("")}>
            显示全部
          </Button>
        ) : null}
      </Card>
      {records.length ? (
        <div className="record-list">
          {records.map((record) => (
            <Card key={record.id} className="record-item">
              <div className="record-date">
                <CalendarDays aria-hidden="true" />
                <span>
                  <strong>{record.date}</strong>
                  <small>{record.time}</small>
                </span>
              </div>
              <div className="record-main">
                <StatusBadge status={record.overall} />
                <p>
                  睡眠：{record.sleep}；精神：{record.spirit}；症状：
                  {record.symptoms.join("、") || "无明显症状"}
                </p>
                {record.note ? <small>备注：{record.note}</small> : null}
              </div>
              <div className="record-actions">
                <Button
                  variant="secondary"
                  icon={Pencil}
                  onClick={() => navigate(`/health/add?id=${record.id}`)}
                >
                  修改
                </Button>
                <Button
                  variant="quiet"
                  icon={Trash2}
                  onClick={() => setDeleting(record)}
                >
                  删除
                </Button>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={History}
          title="这一天还没有身体记录"
          description="可以记录今天的整体状态、睡眠和症状。"
          action={
            <Button icon={Plus} onClick={() => navigate("/health/add")}>
              新增记录
            </Button>
          }
        />
      )}
      <ConfirmDialog
        open={Boolean(deleting)}
        title="确认删除这条身体记录？"
        description="删除后不会在列表中显示。演示模式使用软删除，数据导出时仍可追溯。"
        onCancel={() => setDeleting(null)}
        onConfirm={() => {
          if (!deleting) return;
          update((current) => ({
            ...current,
            healthRecords: current.healthRecords.map((item) =>
              item.id === deleting.id
                ? { ...item, deletedAt: new Date().toISOString() }
                : item,
            ),
          }));
          setDeleting(null);
          showToast("身体记录已删除");
        }}
      />
    </>
  );
}

export function Diseases() {
  const { data, update } = useStore();
  const { showToast } = useToast();
  const [status, setStatus] = useState("全部");
  const [editing, setEditing] = useState<Disease | null>(null);
  const [deleting, setDeleting] = useState<Disease | null>(null);
  const visible = data.diseases.filter(
    (item) => !item.deletedAt && (status === "全部" || item.status === status),
  );

  const emptyDisease = (): Disease => ({
    id: uid(),
    name: "",
    diagnosisDate: "",
    status: "治疗中",
    hospital: "",
    doctor: "",
    precautions: "",
    note: "",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  });

  return (
    <>
      <PageHeader
        title="疾病档案"
        description="集中管理确诊信息和复查事项"
        backHref="/health"
        action={
          <Button icon={Plus} onClick={() => setEditing(emptyDisease())}>
            添加疾病
          </Button>
        }
      />
      <div className="filter-chips" role="group" aria-label="按状态筛选">
        {["全部", "治疗中", "稳定", "需要复查", "已结束"].map((item) => (
          <button
            key={item}
            className={status === item ? "filter-active" : ""}
            aria-pressed={status === item}
            onClick={() => setStatus(item)}
          >
            {item}
          </button>
        ))}
      </div>
      {visible.length ? (
        <div className="record-list">
          {visible.map((disease) => (
            <Card key={disease.id} className="disease-card">
              <div>
                <StatusBadge status={disease.status} />
                <h2>{disease.name}</h2>
                <p>
                  确诊日期：{disease.diagnosisDate || "未填写"}
                  <br />
                  就诊医院：{disease.hospital || "未填写"}
                </p>
              </div>
              <div className="record-actions">
                <Button
                  variant="secondary"
                  icon={Pencil}
                  onClick={() => setEditing(disease)}
                >
                  查看或修改
                </Button>
                <Button
                  variant="quiet"
                  icon={Trash2}
                  onClick={() => setDeleting(disease)}
                >
                  删除
                </Button>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={FileHeart}
          title="没有符合条件的疾病档案"
          description="添加后可记录确诊日期、医院、医生和注意事项。"
        />
      )}

      {editing ? (
        <div className="dialog-backdrop" role="presentation">
          <div className="dialog dialog-wide" role="dialog" aria-modal="true">
            <h2>{editing.name ? "疾病详情" : "添加疾病档案"}</h2>
            <form
              className="form-stack"
              onSubmit={(event) => {
                event.preventDefault();
                if (!editing.name.trim()) {
                  showToast("请填写疾病名称", "error");
                  return;
                }
                update((current) => ({
                  ...current,
                  diseases: [
                    ...current.diseases.filter((item) => item.id !== editing.id),
                    { ...editing, updatedAt: new Date().toISOString() },
                  ],
                }));
                setEditing(null);
                showToast("疾病档案已保存");
              }}
            >
              <div className="form-grid">
                <Field label="疾病名称">
                  <Input
                    value={editing.name}
                    onChange={(event) =>
                      setEditing({ ...editing, name: event.target.value })
                    }
                    required
                  />
                </Field>
                <Field label="确诊日期">
                  <Input
                    type="date"
                    value={editing.diagnosisDate}
                    onChange={(event) =>
                      setEditing({
                        ...editing,
                        diagnosisDate: event.target.value,
                      })
                    }
                  />
                </Field>
                <Field label="当前状态">
                  <Select
                    value={editing.status}
                    onChange={(event) =>
                      setEditing({
                        ...editing,
                        status: event.target.value as Disease["status"],
                      })
                    }
                  >
                    {["治疗中", "稳定", "需要复查", "已结束"].map((item) => (
                      <option key={item}>{item}</option>
                    ))}
                  </Select>
                </Field>
                <Field label="就诊医院">
                  <Input
                    value={editing.hospital}
                    onChange={(event) =>
                      setEditing({ ...editing, hospital: event.target.value })
                    }
                  />
                </Field>
                <Field label="主治医生">
                  <Input
                    value={editing.doctor}
                    onChange={(event) =>
                      setEditing({ ...editing, doctor: event.target.value })
                    }
                  />
                </Field>
              </div>
              <Field label="注意事项">
                <Textarea
                  value={editing.precautions}
                  onChange={(event) =>
                    setEditing({
                      ...editing,
                      precautions: event.target.value,
                    })
                  }
                />
              </Field>
              <Field label="备注">
                <Textarea
                  value={editing.note}
                  onChange={(event) =>
                    setEditing({ ...editing, note: event.target.value })
                  }
                />
              </Field>
              <div className="dialog-actions">
                <Button
                  type="button"
                  variant="secondary"
                  onClick={() => setEditing(null)}
                >
                  取消
                </Button>
                <Button type="submit">保存疾病档案</Button>
              </div>
            </form>
          </div>
        </div>
      ) : null}

      <ConfirmDialog
        open={Boolean(deleting)}
        title="确认删除疾病档案？"
        description="档案删除后不会显示，请确认这是你想删除的内容。"
        onCancel={() => setDeleting(null)}
        onConfirm={() => {
          if (!deleting) return;
          update((current) => ({
            ...current,
            diseases: current.diseases.map((item) =>
              item.id === deleting.id
                ? { ...item, deletedAt: new Date().toISOString() }
                : item,
            ),
          }));
          setDeleting(null);
          showToast("疾病档案已删除");
        }}
      />
    </>
  );
}
