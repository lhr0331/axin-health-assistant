"use client";

import {
  ArrowRight,
  BellRing,
  CalendarCheck,
  Check,
  ChevronLeft,
  ClipboardPlus,
  HeartPulse,
  ShieldCheck,
  Soup,
  Stethoscope,
} from "lucide-react";
import { useState } from "react";
import { navigate } from "@/components/AppShell";
import { Button, Card } from "@/components/ui";
import { useStore } from "@/lib/store";

export function Login() {
  return (
    <div className="entry-shell">
      <div className="entry-brand">
        <span className="brand-mark">
          <ShieldCheck aria-hidden="true" />
        </span>
        <strong>安心健康助手</strong>
      </div>
      <main className="login-layout">
        <section className="login-copy">
          <span className="entry-kicker">为 50 岁以上用户设计</span>
          <h1>每天记一点，健康更安心</h1>
          <p>用更大的字、更简单的步骤，记录身体、用药、饮食和重要事项。</p>
          <ul>
            <li>
              <Check aria-hidden="true" />
              不注册也能体验
            </li>
            <li>
              <Check aria-hidden="true" />
              演示数据只保存在当前浏览器
            </li>
            <li>
              <Check aria-hidden="true" />
              不提供医学诊断，不改变医生方案
            </li>
          </ul>
        </section>
        <Card className="login-card">
          <HeartPulse className="login-icon" aria-hidden="true" />
          <h2>欢迎使用</h2>
          <p>第一阶段提供演示模式。手机号账户与云端同步接口已预留，暂未开放。</p>
          <Button icon={ArrowRight} onClick={() => navigate("/onboarding")}>
            进入演示模式
          </Button>
          <Button variant="secondary" disabled>
            手机号登录（即将开放）
          </Button>
          <small>
            继续即表示你了解：清除浏览器数据后，本地记录可能丢失。
          </small>
        </Card>
      </main>
      <footer className="entry-footer">
        <a href="/privacy" data-nav>
          隐私政策
        </a>
        <span>·</span>
        <a href="/help" data-nav>
          帮助说明
        </a>
      </footer>
    </div>
  );
}

const steps = [
  {
    title: "记录身体情况",
    description: "每天花一分钟，选择整体状态、睡眠和常见症状。",
    icon: Stethoscope,
  },
  {
    title: "设置吃药提醒",
    description: "添加药品和多个服用时间，到点查看醒目提醒。",
    icon: BellRing,
  },
  {
    title: "记录每日饮食",
    description: "快速点选早餐、午餐、晚餐和饮水。",
    icon: Soup,
  },
  {
    title: "管理每日备忘",
    description: "记下复诊、买药、运动和联系家人等重要事项。",
    icon: CalendarCheck,
  },
];

export function Onboarding() {
  const { updateSettings } = useStore();
  const [step, setStep] = useState(0);
  const current = steps[step];
  const Icon = current.icon;
  const finish = () => {
    updateSettings({ onboardingDone: true });
    navigate("/settings/notifications");
  };
  return (
    <div className="onboarding-shell">
      <div className="onboarding-top">
        <div className="entry-brand">
          <span className="brand-mark">
            <ShieldCheck aria-hidden="true" />
          </span>
          <strong>安心健康助手</strong>
        </div>
        <button className="skip-link" onClick={() => navigate("/home")}>
          跳过引导
        </button>
      </div>
      <main className="onboarding-main">
        <div className="step-count" aria-label={`第 ${step + 1} 步，共 4 步`}>
          {steps.map((_, index) => (
            <span key={index} className={index <= step ? "step-active" : ""} />
          ))}
        </div>
        <span className="onboarding-icon">
          <Icon aria-hidden="true" />
        </span>
        <p className="step-label">第 {step + 1} 步，共 4 步</p>
        <h1>{current.title}</h1>
        <p>{current.description}</p>
        <div className="onboarding-actions">
          {step > 0 ? (
            <Button
              variant="secondary"
              icon={ChevronLeft}
              onClick={() => setStep((value) => value - 1)}
            >
              上一步
            </Button>
          ) : null}
          {step < steps.length - 1 ? (
            <Button
              icon={ArrowRight}
              onClick={() => setStep((value) => value + 1)}
            >
              下一步
            </Button>
          ) : (
            <Button icon={ClipboardPlus} onClick={finish}>
              开始使用
            </Button>
          )}
        </div>
      </main>
    </div>
  );
}
