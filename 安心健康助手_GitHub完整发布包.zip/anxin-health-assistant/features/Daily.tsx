"use client";

import {
  CalendarCheck,
  Check,
  Clock3,
  CupSoda,
  ImagePlus,
  Pencil,
  Plus,
  Soup,
  Trash2,
} from "lucide-react";
import { useState } from "react";
import { navigate } from "@/components/AppShell";
import {
  Button,
  Card,
  ChoiceGroup,
  ConfirmDialog,
  EmptyState,
  Field,
  Input,
  PageHeader,
  StatusBadge,
  Textarea,
  useToast,
} from "@/components/ui";
import { isoDate, timeNow, uid } from "@/lib/date";
import { getAppSearchParams } from "@/lib/app-location";
import { useStore } from "@/lib/store";
import type { MealRecord, Memo } from "@/lib/types";

const memoCategories = [
  "看医生",
  "买药",
  "测血压",
  "测血糖",
  "运动",
  "联系家人",
  "其他",
];

export function Memos() {
  const { data, update } = useStore();
  const { showToast } = useToast();
  const [date, setDate] = useState(isoDate());
  const [deleting, setDeleting] = useState<Memo | null>(null);
  const memos = data.memos
    .filter((item) => item.date === date && !item.deletedAt)
    .sort((a, b) => a.time.localeCompare(b.time));
  return (
    <>
      <PageHeader
        title="每日备忘"
        description="把重要的事记下来，完成后打个勾"
        action={
          <Button icon={Plus} onClick={() => navigate("/memos/add")}>
            添加备忘
          </Button>
        }
      />
      <Card className="filter-card">
        <Field label="查看日期">
          <Input
            type="date"
            value={date}
            onChange={(event) => setDate(event.target.value)}
          />
        </Field>
      </Card>
      {memos.length ? (
        <div className="record-list">
          {memos.map((memo) => (
            <Card key={memo.id} className={`memo-card ${memo.completed ? "memo-done" : ""}`}>
              <button
                className="memo-check"
                aria-label={memo.completed ? "标记为未完成" : "标记为已完成"}
                aria-pressed={memo.completed}
                onClick={() => {
                  update((current) => ({
                    ...current,
                    memos: current.memos.map((item) =>
                      item.id === memo.id
                        ? {
                            ...item,
                            completed: !item.completed,
                            updatedAt: new Date().toISOString(),
                          }
                        : item,
                    ),
                  }));
                  showToast(memo.completed ? "已恢复为待完成" : "备忘已完成");
                }}
              >
                {memo.completed ? <Check aria-hidden="true" /> : null}
              </button>
              <div className="memo-main">
                <div className="med-title-row">
                  <h2>{memo.title}</h2>
                  <StatusBadge status={memo.completed ? "已完成" : "待完成"} />
                </div>
                <p>
                  <Clock3 aria-hidden="true" />
                  {memo.time || "未设置时间"} · {memo.category}
                  {memo.reminderEnabled ? " · 已开启提醒" : ""}
                </p>
                {memo.note ? <small>{memo.note}</small> : null}
              </div>
              <div className="record-actions">
                <Button
                  variant="secondary"
                  icon={Pencil}
                  onClick={() => navigate(`/memos/add?id=${memo.id}`)}
                >
                  编辑
                </Button>
                <Button
                  variant="quiet"
                  icon={Trash2}
                  onClick={() => setDeleting(memo)}
                >
                  删除
                </Button>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={CalendarCheck}
          title="这一天没有备忘"
          description="可以添加看医生、买药、运动或联系家人等事项。"
        />
      )}
      <ConfirmDialog
        open={Boolean(deleting)}
        title="确认删除这个备忘？"
        description="删除后不会继续提醒。"
        onCancel={() => setDeleting(null)}
        onConfirm={() => {
          if (!deleting) return;
          update((current) => ({
            ...current,
            memos: current.memos.map((item) =>
              item.id === deleting.id
                ? { ...item, deletedAt: new Date().toISOString() }
                : item,
            ),
          }));
          setDeleting(null);
          showToast("备忘已删除");
        }}
      />
    </>
  );
}

export function MemoForm() {
  const { data, update } = useStore();
  const { showToast } = useToast();
  const queryId =
    typeof window === "undefined"
      ? null
      : getAppSearchParams().get("id");
  const existing = data.memos.find((item) => item.id === queryId);
  const [form, setForm] = useState<Memo>(
    existing || {
      id: uid(),
      title: "",
      category: "看医生",
      date: isoDate(),
      time: "15:00",
      reminderEnabled: true,
      note: "",
      completed: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
  );
  return (
    <>
      <PageHeader
        title={existing ? "编辑备忘" : "添加备忘"}
        description="只需填写重要信息，备注可以留空。"
        backHref="/memos"
      />
      <Card>
        <form
          className="form-stack"
          onSubmit={(event) => {
            event.preventDefault();
            if (!form.title.trim()) {
              showToast("请填写备忘标题", "error");
              return;
            }
            update((current) => ({
              ...current,
              memos: [
                ...current.memos.filter((item) => item.id !== form.id),
                { ...form, updatedAt: new Date().toISOString() },
              ],
            }));
            showToast("备忘已保存");
            navigate("/memos");
          }}
        >
          <Field label="标题">
            <Input
              value={form.title}
              placeholder="例如：下午 3 点去医院复查"
              onChange={(event) =>
                setForm({ ...form, title: event.target.value })
              }
              required
            />
          </Field>
          <Field label="快捷分类">
            <ChoiceGroup
              options={memoCategories}
              value={form.category}
              onChange={(value) =>
                setForm({ ...form, category: value as string })
              }
              ariaLabel="选择备忘分类"
            />
          </Field>
          <div className="form-grid">
            <Field label="日期">
              <Input
                type="date"
                value={form.date}
                onChange={(event) =>
                  setForm({ ...form, date: event.target.value })
                }
                required
              />
            </Field>
            <Field label="时间">
              <Input
                type="time"
                value={form.time}
                onChange={(event) =>
                  setForm({ ...form, time: event.target.value })
                }
              />
            </Field>
          </div>
          <Field label="备注">
            <Textarea
              value={form.note}
              onChange={(event) => setForm({ ...form, note: event.target.value })}
            />
          </Field>
          <label className="toggle-row">
            <span>
              <strong>到点提醒</strong>
              <small>浏览器允许通知时会发送提醒</small>
            </span>
            <input
              type="checkbox"
              checked={form.reminderEnabled}
              onChange={(event) =>
                setForm({ ...form, reminderEnabled: event.target.checked })
              }
            />
          </label>
          <div className="sticky-form-actions">
            <Button type="submit" icon={CalendarCheck}>
              保存备忘
            </Button>
            <Button
              type="button"
              variant="secondary"
              onClick={() => navigate("/memos")}
            >
              取消
            </Button>
          </div>
        </form>
      </Card>
    </>
  );
}

const foodOptions = [
  "米饭",
  "面条",
  "粥",
  "鸡蛋",
  "牛奶",
  "蔬菜",
  "水果",
  "肉类",
  "豆制品",
  "药膳",
  "其他",
];

export function Meals() {
  const { data, update } = useStore();
  const { showToast } = useToast();
  const [date, setDate] = useState(isoDate());
  const [deleting, setDeleting] = useState<MealRecord | null>(null);
  const meals = data.meals
    .filter((item) => item.date === date && !item.deletedAt)
    .sort((a, b) => a.time.localeCompare(b.time));
  const logged = new Set(meals.map((item) => item.mealType));
  return (
    <>
      <PageHeader
        title="每日饮食"
        description="简单记录吃了什么，不做医疗饮食诊断"
        action={
          <Button icon={Plus} onClick={() => navigate("/meals/add")}>
            记录饮食
          </Button>
        }
      />
      <div className="meal-status-grid" aria-label="今日三餐记录状态">
        {["早餐", "午餐", "晚餐"].map((meal) => (
          <Card key={meal} className={logged.has(meal as MealRecord["mealType"]) ? "meal-logged" : ""}>
            <span>
              {logged.has(meal as MealRecord["mealType"]) ? (
                <Check aria-hidden="true" />
              ) : (
                <Soup aria-hidden="true" />
              )}
            </span>
            <strong>{meal}</strong>
            <small>{logged.has(meal as MealRecord["mealType"]) ? "已记录" : "还未记录"}</small>
          </Card>
        ))}
      </div>
      <Card className="filter-card">
        <Field label="查看日期">
          <Input
            type="date"
            value={date}
            onChange={(event) => setDate(event.target.value)}
          />
        </Field>
      </Card>
      {meals.length ? (
        <div className="record-list">
          {meals.map((meal) => (
            <Card key={meal.id} className="meal-card">
              <div className="meal-type-icon">
                {meal.mealType === "饮水" ? (
                  <CupSoda aria-hidden="true" />
                ) : (
                  <Soup aria-hidden="true" />
                )}
              </div>
              <div className="meal-main">
                <div className="med-title-row">
                  <h2>{meal.mealType}</h2>
                  <span className="time-text">{meal.time}</span>
                </div>
                <p>{meal.foods || `饮水 ${meal.waterMl} 毫升`}</p>
                <small>
                  分量：{meal.portion}
                  {meal.waterMl ? ` · 饮水 ${meal.waterMl} 毫升` : ""}
                  {meal.photoName ? ` · 已选择照片 ${meal.photoName}` : ""}
                </small>
              </div>
              <div className="record-actions">
                <Button
                  variant="secondary"
                  icon={Pencil}
                  onClick={() => navigate(`/meals/add?id=${meal.id}`)}
                >
                  修改
                </Button>
                <Button
                  variant="quiet"
                  icon={Trash2}
                  onClick={() => setDeleting(meal)}
                >
                  删除
                </Button>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={Soup}
          title="这一天还没有饮食记录"
          description="记录三餐、加餐或饮水，内容可以随时修改。"
        />
      )}
      <ConfirmDialog
        open={Boolean(deleting)}
        title="确认删除这条饮食记录？"
        description="删除后不会在当天饮食中显示。"
        onCancel={() => setDeleting(null)}
        onConfirm={() => {
          if (!deleting) return;
          update((current) => ({
            ...current,
            meals: current.meals.map((item) =>
              item.id === deleting.id
                ? { ...item, deletedAt: new Date().toISOString() }
                : item,
            ),
          }));
          setDeleting(null);
          showToast("饮食记录已删除");
        }}
      />
    </>
  );
}

export function MealForm() {
  const { data, update } = useStore();
  const { showToast } = useToast();
  const queryId =
    typeof window === "undefined"
      ? null
      : getAppSearchParams().get("id");
  const existing = data.meals.find((item) => item.id === queryId);
  const [selectedFoods, setSelectedFoods] = useState<string[]>([]);
  const [form, setForm] = useState<MealRecord>(
    existing || {
      id: uid(),
      date: isoDate(),
      time: timeNow(),
      mealType: "早餐",
      foods: "",
      portion: "正常",
      waterMl: 0,
      note: "",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
  );
  return (
    <>
      <PageHeader
        title={existing ? "修改饮食记录" : "记录饮食"}
        description="可以点选常见食物，也可以直接输入。"
        backHref="/meals"
      />
      <Card>
        <form
          className="form-stack"
          onSubmit={(event) => {
            event.preventDefault();
            const quickFoods = selectedFoods.filter((item) => item !== "其他");
            const foods = [form.foods.trim(), ...quickFoods]
              .filter(Boolean)
              .filter((item, index, all) => all.indexOf(item) === index)
              .join("、");
            if (form.mealType !== "饮水" && !foods) {
              showToast("请填写或选择食物", "error");
              return;
            }
            update((current) => ({
              ...current,
              meals: [
                ...current.meals.filter((item) => item.id !== form.id),
                { ...form, foods, updatedAt: new Date().toISOString() },
              ],
            }));
            showToast("饮食记录已保存");
            navigate("/meals");
          }}
        >
          <div className="form-grid">
            <Field label="日期">
              <Input
                type="date"
                value={form.date}
                onChange={(event) =>
                  setForm({ ...form, date: event.target.value })
                }
              />
            </Field>
            <Field label="时间">
              <Input
                type="time"
                value={form.time}
                onChange={(event) =>
                  setForm({ ...form, time: event.target.value })
                }
              />
            </Field>
          </div>
          <Field label="餐次">
            <ChoiceGroup
              options={["早餐", "午餐", "晚餐", "加餐", "饮水"]}
              value={form.mealType}
              onChange={(value) =>
                setForm({
                  ...form,
                  mealType: value as MealRecord["mealType"],
                })
              }
              ariaLabel="选择餐次"
            />
          </Field>
          {form.mealType !== "饮水" ? (
            <>
              <Field label="快捷选择" hint="可以选择多个">
                <ChoiceGroup
                  options={foodOptions}
                  value={selectedFoods}
                  onChange={(value) => setSelectedFoods(value as string[])}
                  multiple
                  ariaLabel="选择常见食物"
                />
              </Field>
              <Field label="食物名称">
                <Input
                  value={form.foods}
                  placeholder="例如：粥、鸡蛋"
                  onChange={(event) =>
                    setForm({ ...form, foods: event.target.value })
                  }
                />
              </Field>
              <Field label="大概分量">
                <ChoiceGroup
                  options={["少量", "正常", "较多", "自定义"]}
                  value={form.portion}
                  onChange={(value) =>
                    setForm({ ...form, portion: value as string })
                  }
                  ariaLabel="选择分量"
                />
              </Field>
            </>
          ) : null}
          <Field label="饮水量（毫升）" hint="不确定可以填大概数字">
            <Input
              type="number"
              min={0}
              step={50}
              inputMode="numeric"
              value={form.waterMl}
              onChange={(event) =>
                setForm({ ...form, waterMl: Number(event.target.value) })
              }
            />
          </Field>
          <Field label="可选照片" hint="演示模式只保存文件名称，不上传照片">
            <label className="file-input">
              <ImagePlus aria-hidden="true" />
              <span>{form.photoName || "选择一张照片"}</span>
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp"
                onChange={(event) =>
                  setForm({
                    ...form,
                    photoName: event.target.files?.[0]?.name,
                  })
                }
              />
            </label>
          </Field>
          <Field label="备注">
            <Textarea
              value={form.note}
              onChange={(event) => setForm({ ...form, note: event.target.value })}
            />
          </Field>
          <div className="sticky-form-actions">
            <Button type="submit" icon={Soup}>
              保存饮食记录
            </Button>
            <Button
              type="button"
              variant="secondary"
              onClick={() => navigate("/meals")}
            >
              取消
            </Button>
          </div>
        </form>
      </Card>
    </>
  );
}
