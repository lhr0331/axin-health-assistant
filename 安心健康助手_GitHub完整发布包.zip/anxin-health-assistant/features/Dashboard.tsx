"use client";

import {
  ArrowRight,
  CalendarPlus,
  ClipboardPlus,
  HeartPulse,
  Plus,
  Settings,
  Soup,
  Stethoscope,
  SunMedium,
  type LucideIcon,
} from "lucide-react";
import { greeting, isoDate, todayChinese } from "@/lib/date";
import { useStore } from "@/lib/store";
import { Button, Card, Progress, StatusBadge } from "@/components/ui";

function OverviewCard({
  icon: Icon,
  title,
  summary,
  status,
  href,
  action,
  tone,
}: {
  icon: LucideIcon;
  title: string;
  summary: string;
  status: string;
  href: string;
  action: string;
  tone: string;
}) {
  return (
    <Card className={`overview-card tone-${tone}`}>
      <div className="overview-head">
        <span className="overview-icon">
          <Icon aria-hidden="true" />
        </span>
        <StatusBadge status={status} />
      </div>
      <h2>{title}</h2>
      <p>{summary}</p>
      <a href={href} data-nav className="card-action">
        {action}
        <ArrowRight aria-hidden="true" />
      </a>
    </Card>
  );
}

export function Dashboard() {
  const { data, updateSettings } = useStore();
  const today = isoDate();
  const meds = data.medications.filter((item) => !item.deletedAt);
  const totalMedicationTasks = meds.reduce(
    (sum, item) => sum + item.times.length,
    0,
  );
  const completedMedicationTasks = data.medicationLogs.filter(
    (item) => item.date === today && item.status === "已服用",
  ).length;
  const meals = data.meals.filter((item) => item.date === today && !item.deletedAt);
  const mealTypes = new Set(meals.map((item) => item.mealType));
  const todayHealth = data.healthRecords.find(
    (item) => item.date === today && !item.deletedAt,
  );
  const todayMemos = data.memos.filter(
    (item) => item.date === today && !item.deletedAt && !item.completed,
  );

  return (
    <>
      <div className="home-hero">
        <div>
          <div className="eyebrow">
            <SunMedium aria-hidden="true" />
            {todayChinese()}
          </div>
          <h1>
            {greeting()}，{data.profile.name || "安心用户"}
          </h1>
          <p>先看看今天最重要的健康安排，一件一件完成就好。</p>
        </div>
        <div className="hero-actions">
          <Button
            variant="secondary"
            icon={HeartPulse}
            onClick={() =>
              updateSettings({ largeText: !data.settings.largeText })
            }
          >
            {data.settings.largeText ? "标准字体" : "大字体"}
          </Button>
          <a href="/settings" data-nav className="icon-text-link">
            <Settings aria-hidden="true" />
            设置
          </a>
        </div>
      </div>

      <section aria-labelledby="overview-title">
        <div className="section-heading">
          <div>
            <h2 id="overview-title">今日概览</h2>
            <p>你今天的记录和安排</p>
          </div>
        </div>
        <div className="overview-grid">
          <OverviewCard
            icon={ClipboardPlus}
            title="今日用药"
            summary={`已完成 ${completedMedicationTasks} 次，共 ${totalMedicationTasks} 次`}
            status={
              completedMedicationTasks === totalMedicationTasks &&
              totalMedicationTasks > 0
                ? "已完成"
                : "待完成"
            }
            href="/medications/today"
            action="查看今日用药"
            tone="teal"
          />
          <OverviewCard
            icon={Soup}
            title="今日饮食"
            summary={
              mealTypes.size
                ? `已记录${[...mealTypes].join("、")}`
                : "今天还没有记录饮食"
            }
            status={mealTypes.size >= 3 ? "已完成" : "待完成"}
            href="/meals"
            action="记录饮食"
            tone="amber"
          />
          <OverviewCard
            icon={Stethoscope}
            title="身体记录"
            summary={
              todayHealth
                ? `今日整体状态：${todayHealth.overall}`
                : "今天还没有记录身体情况"
            }
            status={todayHealth ? "已记录" : "待记录"}
            href="/health/add"
            action={todayHealth ? "查看或修改" : "现在记录"}
            tone="blue"
          />
          <OverviewCard
            icon={CalendarPlus}
            title="今日备忘"
            summary={
              todayMemos[0]?.title ||
              (data.memos.some((item) => item.date === today && item.completed)
                ? "今天的备忘已完成"
                : "今天没有待办事项")
            }
            status={todayMemos.length ? "待完成" : "已完成"}
            href="/memos"
            action="查看备忘"
            tone="green"
          />
        </div>
      </section>

      <Card className="med-progress-card">
        <div>
          <span className="card-kicker">服药进度</span>
          <h2>今天需要服药 {totalMedicationTasks} 次</h2>
          <p>已经完成 {completedMedicationTasks} 次，记录后可随时撤销。</p>
        </div>
        <Progress
          value={completedMedicationTasks}
          max={totalMedicationTasks}
          label="今日服药完成进度"
        />
      </Card>

      <section aria-labelledby="quick-title">
        <div className="section-heading">
          <div>
            <h2 id="quick-title">快捷操作</h2>
            <p>三次点击以内完成常用记录</p>
          </div>
        </div>
        <div className="quick-grid">
          <a href="/health/add" data-nav>
            <Stethoscope aria-hidden="true" />
            <span>记录身体状况</span>
            <Plus aria-hidden="true" />
          </a>
          <a href="/medications/today" data-nav>
            <ClipboardPlus aria-hidden="true" />
            <span>记录吃药</span>
            <Plus aria-hidden="true" />
          </a>
          <a href="/meals/add" data-nav>
            <Soup aria-hidden="true" />
            <span>记录饮食</span>
            <Plus aria-hidden="true" />
          </a>
          <a href="/memos/add" data-nav>
            <CalendarPlus aria-hidden="true" />
            <span>添加备忘</span>
            <Plus aria-hidden="true" />
          </a>
        </div>
      </section>
    </>
  );
}
