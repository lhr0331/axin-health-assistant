"use client";

import {
  Activity,
  AlertTriangle,
  BarChart3,
  ClipboardCheck,
  FilePlus2,
  FileText,
  Pencil,
  Plus,
  ShieldCheck,
  Trash2,
} from "lucide-react";
import { useMemo, useState } from "react";
import { z } from "zod";
import { navigate } from "@/components/AppShell";
import {
  Button,
  Card,
  ConfirmDialog,
  EmptyState,
  Field,
  Input,
  PageHeader,
  Select,
  StatusBadge,
  Textarea,
  useToast,
} from "@/components/ui";
import { buildExaminationAnalysis } from "@/lib/exam-analysis";
import { getAppSearchParams } from "@/lib/app-location";
import { isoDate, uid } from "@/lib/date";
import { useStore } from "@/lib/store";
import type {
  ExaminationMetric,
  ExaminationReport,
} from "@/lib/types";

type MetricDraft = {
  id: string;
  key: string;
  name: string;
  value: string;
  unit: string;
  referenceMin: string;
  referenceMax: string;
  custom: boolean;
};

const standardMetrics: Array<
  Pick<MetricDraft, "key" | "name" | "unit">
> = [
  { key: "systolic-bp", name: "收缩压", unit: "mmHg" },
  { key: "diastolic-bp", name: "舒张压", unit: "mmHg" },
  { key: "fasting-glucose", name: "空腹血糖", unit: "mmol/L" },
  { key: "weight", name: "体重", unit: "kg" },
  { key: "total-cholesterol", name: "总胆固醇", unit: "mmol/L" },
  { key: "triglycerides", name: "甘油三酯", unit: "mmol/L" },
  { key: "uric-acid", name: "尿酸", unit: "μmol/L" },
  { key: "creatinine", name: "肌酐", unit: "μmol/L" },
];

const reportSchema = z.object({
  reportDate: z.string().min(1, "请选择体检日期"),
  title: z.string().trim().min(2, "请填写报告名称"),
  hospital: z.string().trim().min(2, "请填写体检机构"),
  metrics: z
    .array(
      z
        .object({
          id: z.string(),
          key: z.string().min(1),
          name: z.string().trim().min(1, "请填写指标名称"),
          value: z.number().finite("指标数值必须是数字"),
          unit: z.string().trim().min(1, "请填写单位"),
          referenceMin: z.number().finite().optional(),
          referenceMax: z.number().finite().optional(),
        })
        .superRefine((metric, context) => {
          if (
            metric.referenceMin !== undefined &&
            metric.referenceMax !== undefined &&
            metric.referenceMin > metric.referenceMax
          ) {
            context.addIssue({
              code: "custom",
              message: `${metric.name}的参考范围下限不能大于上限`,
              path: ["referenceMin"],
            });
          }
        }),
    )
    .min(1, "请至少填写一项体检指标"),
});

function draftFromMetric(metric: ExaminationMetric): MetricDraft {
  return {
    id: metric.id,
    key: metric.key,
    name: metric.name,
    value: String(metric.value),
    unit: metric.unit,
    referenceMin:
      metric.referenceMin === undefined ? "" : String(metric.referenceMin),
    referenceMax:
      metric.referenceMax === undefined ? "" : String(metric.referenceMax),
    custom: !standardMetrics.some((item) => item.key === metric.key),
  };
}

function emptyDrafts(): MetricDraft[] {
  return standardMetrics.map((metric) => ({
    id: uid(),
    ...metric,
    value: "",
    referenceMin: "",
    referenceMax: "",
    custom: false,
  }));
}

function optionalNumber(value: string) {
  return value.trim() === "" ? undefined : Number(value);
}

function draftKey(draft: MetricDraft) {
  if (!draft.custom) return draft.key;
  const normalized = draft.name.trim().toLowerCase().replace(/\s+/g, "-");
  return normalized ? `custom-${normalized}` : draft.key;
}

function metricsFromDrafts(drafts: MetricDraft[]): ExaminationMetric[] {
  return drafts
    .filter((draft) => draft.value.trim() !== "")
    .map((draft) => ({
      id: draft.id,
      key: draftKey(draft),
      name: draft.name.trim(),
      value: Number(draft.value),
      unit: draft.unit.trim(),
      referenceMin: optionalNumber(draft.referenceMin),
      referenceMax: optionalNumber(draft.referenceMax),
    }));
}

function metricStatus(metric: ExaminationMetric) {
  if (
    metric.referenceMin !== undefined &&
    metric.value < metric.referenceMin
  ) {
    return "低于参考范围";
  }
  if (
    metric.referenceMax !== undefined &&
    metric.value > metric.referenceMax
  ) {
    return "高于参考范围";
  }
  if (
    metric.referenceMin !== undefined ||
    metric.referenceMax !== undefined
  ) {
    return "参考范围内";
  }
  return "待核对";
}

function formatDate(date: string) {
  return new Intl.DateTimeFormat("zh-CN", {
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(new Date(`${date}T00:00:00`));
}

function ReportTrendChart({
  reports,
  metricKey,
}: {
  reports: ExaminationReport[];
  metricKey: string;
}) {
  const points = useMemo(
    () =>
      reports
        .filter((report) => !report.deletedAt)
        .flatMap((report) => {
          const metric = report.metrics.find((item) => item.key === metricKey);
          return metric ? [{ report, metric }] : [];
        })
        .sort((a, b) => a.report.reportDate.localeCompare(b.report.reportDate)),
    [metricKey, reports],
  );

  if (!points.length) {
    return (
      <EmptyState
        icon={BarChart3}
        title="还没有这个指标的数据"
        description="添加一份包含该指标的体检报告后，这里会显示趋势。"
      />
    );
  }

  const allNumbers = points.flatMap(({ metric }) => [
    metric.value,
    ...(metric.referenceMin === undefined ? [] : [metric.referenceMin]),
    ...(metric.referenceMax === undefined ? [] : [metric.referenceMax]),
  ]);
  const rawMin = Math.min(...allNumbers);
  const rawMax = Math.max(...allNumbers);
  const span = Math.max(rawMax - rawMin, Math.abs(rawMax || 1) * 0.12, 1);
  const min = rawMin - span * 0.16;
  const max = rawMax + span * 0.2;
  const width = 780;
  const height = 330;
  const left = 72;
  const right = 28;
  const top = 38;
  const bottom = 58;
  const plotWidth = width - left - right;
  const plotHeight = height - top - bottom;
  const x = (index: number) =>
    points.length === 1
      ? left + plotWidth / 2
      : left + (index * plotWidth) / (points.length - 1);
  const y = (value: number) =>
    top + ((max - value) / Math.max(max - min, 1)) * plotHeight;
  const linePath = points
    .map(({ metric }, index) => `${index ? "L" : "M"} ${x(index)} ${y(metric.value)}`)
    .join(" ");
  const metricName = points[0].metric.name;
  const metricUnit = points[0].metric.unit;
  const ticks = Array.from({ length: 5 }, (_, index) => {
    const value = max - ((max - min) * index) / 4;
    return { value, y: y(value) };
  });

  return (
    <>
      <div className="exam-chart" role="img" aria-labelledby="exam-chart-title">
        <svg viewBox={`0 0 ${width} ${height}`} aria-hidden="true">
          <title id="exam-chart-title">
            {metricName}历次体检趋势，共 {points.length} 次记录
          </title>
          {ticks.map((tick) => (
            <g key={tick.value}>
              <line
                x1={left}
                x2={width - right}
                y1={tick.y}
                y2={tick.y}
                className="chart-grid-line"
              />
              <text x={left - 10} y={tick.y + 5} textAnchor="end">
                {Number(tick.value.toFixed(1))}
              </text>
            </g>
          ))}
          <path d={linePath} className="chart-trend-line" />
          {points.map(({ report, metric }, index) => {
            const previousValue =
              index === 0 ? metric.value : points[index - 1].metric.value;
            const startY = y(previousValue);
            const endY = y(metric.value);
            const bodyHeight = Math.max(8, Math.abs(startY - endY));
            const bodyY =
              Math.abs(startY - endY) < 8
                ? endY - bodyHeight / 2
                : Math.min(startY, endY);
            const status = metricStatus(metric);
            const change =
              index === 0
                ? "首次"
                : metric.value > previousValue
                  ? "上升"
                  : metric.value < previousValue
                    ? "下降"
                    : "持平";
            return (
              <g key={report.id}>
                {metric.referenceMin !== undefined &&
                metric.referenceMax !== undefined ? (
                  <line
                    x1={x(index)}
                    x2={x(index)}
                    y1={y(metric.referenceMax)}
                    y2={y(metric.referenceMin)}
                    className="chart-reference-range"
                  />
                ) : null}
                <rect
                  x={x(index) - 12}
                  y={bodyY}
                  width={24}
                  height={bodyHeight}
                  rx={4}
                  className={
                    status === "参考范围内"
                      ? "chart-candle-safe"
                      : status === "待核对"
                        ? "chart-candle-pending"
                        : "chart-candle-attention"
                  }
                />
                <circle
                  cx={x(index)}
                  cy={endY}
                  r={5}
                  className="chart-current-point"
                />
                <text
                  x={x(index)}
                  y={Math.max(18, endY - 14)}
                  textAnchor="middle"
                  className="chart-value-label"
                >
                  {metric.value}
                </text>
                <text
                  x={x(index)}
                  y={height - 28}
                  textAnchor="middle"
                  className="chart-date-label"
                >
                  {report.reportDate.slice(5).replace("-", "/")}
                </text>
                <text
                  x={x(index)}
                  y={height - 9}
                  textAnchor="middle"
                  className="chart-change-label"
                >
                  {change}
                </text>
              </g>
            );
          })}
        </svg>
      </div>
      <p className="chart-explanation">
        粗柱表示与上次体检相比的变化，圆点是本次值，浅色竖线是该份报告中填写的参考范围。
        第一次记录显示为短柱。
      </p>
      <div className="metric-history" aria-label={`${metricName}全部历史数据`}>
        {points
          .slice()
          .reverse()
          .map(({ report, metric }, reverseIndex) => {
            const index = points.length - 1 - reverseIndex;
            const previous = index > 0 ? points[index - 1].metric.value : undefined;
            const change =
              previous === undefined
                ? "首次记录"
                : `${metric.value >= previous ? "+" : ""}${Number(
                    (metric.value - previous).toFixed(2),
                  )} ${metric.unit}`;
            const range =
              metric.referenceMin === undefined &&
              metric.referenceMax === undefined
                ? "未填写"
                : `${metric.referenceMin ?? "未填"} 至 ${
                    metric.referenceMax ?? "未填"
                  } ${metric.unit}`;
            return (
              <div className="metric-history-row" key={report.id}>
                <div>
                  <strong>{formatDate(report.reportDate)}</strong>
                  <small>{report.title}</small>
                </div>
                <div>
                  <span>本次结果</span>
                  <strong>
                    {metric.value} {metricUnit}
                  </strong>
                </div>
                <div>
                  <span>比上次</span>
                  <strong>{change}</strong>
                </div>
                <div>
                  <span>报告参考范围</span>
                  <strong>{range}</strong>
                </div>
                <StatusBadge status={metricStatus(metric)} />
              </div>
            );
          })}
      </div>
    </>
  );
}

export function ExaminationReports() {
  const { data, update } = useStore();
  const { showToast } = useToast();
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const reports = data.examinationReports
    .filter((report) => !report.deletedAt)
    .sort((a, b) => b.reportDate.localeCompare(a.reportDate));
  const metricOptions = useMemo(() => {
    const options = new Map<string, string>();
    for (const report of reports) {
      for (const metric of report.metrics) {
        if (!options.has(metric.key)) options.set(metric.key, metric.name);
      }
    }
    return [...options.entries()];
  }, [reports]);
  const [selectedMetric, setSelectedMetric] = useState(
    metricOptions.find(([key]) => key === "systolic-bp")?.[0] ??
      metricOptions[0]?.[0] ??
      "",
  );
  const activeMetric = metricOptions.some(([key]) => key === selectedMetric)
    ? selectedMetric
    : metricOptions[0]?.[0] ?? "";
  const latest = reports[0];

  return (
    <>
      <PageHeader
        title="体检报告趋势"
        description="保存每次体检的原始数据，查看变化，并在录入后立即生成安全提示。"
        backHref="/health"
        action={
          <Button icon={FilePlus2} onClick={() => navigate("/reports/add")}>
            添加体检报告
          </Button>
        }
      />

      {latest ? (
        <Card className="latest-analysis-card">
          <div className="analysis-card-heading">
            <span className="feature-icon">
              <ClipboardCheck aria-hidden="true" />
            </span>
            <div>
              <span className="card-kicker">最新分析</span>
              <h2>{latest.title}</h2>
              <p>{formatDate(latest.reportDate)}</p>
            </div>
          </div>
          <p className="analysis-summary">{latest.analysis.summary}</p>
          <div className="analysis-counts" aria-label="最新报告分析数量">
            <span>
              <strong>{latest.analysis.inRangeCount}</strong>
              参考范围内
            </span>
            <span>
              <strong>{latest.analysis.attentionCount}</strong>
              需要核对
            </span>
            <span>
              <strong>{latest.analysis.pendingCount}</strong>
              缺少范围
            </span>
          </div>
          <Button
            variant="secondary"
            onClick={() => navigate(`/reports/detail?id=${latest.id}`)}
          >
            查看完整分析
          </Button>
        </Card>
      ) : null}

      <section aria-labelledby="trend-title">
        <div className="section-heading report-section-heading">
          <div>
            <h2 id="trend-title">健康指标 K 线</h2>
            <p>每个数值都保留在下方明细中，颜色不会作为唯一判断依据。</p>
          </div>
          {metricOptions.length ? (
            <Field label="选择要查看的指标">
              <Select
                value={activeMetric}
                onChange={(event) => setSelectedMetric(event.target.value)}
              >
                {metricOptions.map(([key, name]) => (
                  <option value={key} key={key}>
                    {name}
                  </option>
                ))}
              </Select>
            </Field>
          ) : null}
        </div>
        <Card className="trend-card">
          {activeMetric ? (
            <ReportTrendChart reports={reports} metricKey={activeMetric} />
          ) : (
            <EmptyState
              icon={BarChart3}
              title="还没有体检趋势"
              description="添加第一份体检报告后，这里会自动生成趋势 K 线。"
              action={
                <Button
                  icon={Plus}
                  onClick={() => navigate("/reports/add")}
                >
                  添加第一份报告
                </Button>
              }
            />
          )}
        </Card>
      </section>

      <section aria-labelledby="report-history-title">
        <div className="section-heading">
          <div>
            <h2 id="report-history-title">历次体检报告</h2>
            <p>共 {reports.length} 份，按日期从新到旧排列</p>
          </div>
        </div>
        {reports.length ? (
          <div className="report-list">
            {reports.map((report) => (
              <Card className="report-item" as="article" key={report.id}>
                <div className="report-date-block">
                  <span>{report.reportDate.slice(5).replace("-", "月")}日</span>
                  <small>{report.reportDate.slice(0, 4)}年</small>
                </div>
                <div className="report-main">
                  <div className="report-title-row">
                    <div>
                      <h3>{report.title}</h3>
                      <p>
                        {report.hospital}，已记录 {report.metrics.length} 项指标
                      </p>
                    </div>
                    <StatusBadge
                      status={
                        report.analysis.attentionCount
                          ? `${report.analysis.attentionCount} 项需核对`
                          : "已完成分析"
                      }
                    />
                  </div>
                  <p>{report.analysis.summary}</p>
                  <div className="button-row">
                    <Button
                      variant="secondary"
                      icon={FileText}
                      onClick={() =>
                        navigate(`/reports/detail?id=${report.id}`)
                      }
                    >
                      查看数据和分析
                    </Button>
                    <Button
                      variant="quiet"
                      icon={Pencil}
                      onClick={() =>
                        navigate(`/reports/add?id=${report.id}`)
                      }
                    >
                      修改
                    </Button>
                    <Button
                      variant="quiet"
                      icon={Trash2}
                      onClick={() => setDeleteId(report.id)}
                    >
                      删除
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <EmptyState
            icon={FileText}
            title="还没有体检报告"
            description="添加后会自动保存原始数值、参考范围、趋势和分析。"
          />
        )}
      </section>

      <Card className="safety-note">
        <ShieldCheck aria-hidden="true" />
        <div>
          <h2>分析边界</h2>
          <p>
            本功能只比较你填写的报告参考范围和历史变化，不提供医学诊断。
            不同医院、年龄、性别和检查方法的参考范围可能不同，请以原报告和医生解释为准。
          </p>
        </div>
      </Card>

      <ConfirmDialog
        open={Boolean(deleteId)}
        title="确认删除这份体检报告吗？"
        description="删除后，这份报告不会再出现在趋势和分析中。演示模式会使用软删除保留恢复空间。"
        onCancel={() => setDeleteId(null)}
        onConfirm={() => {
          if (!deleteId) return;
          update((current) => ({
            ...current,
            examinationReports: current.examinationReports.map((report) =>
              report.id === deleteId
                ? { ...report, deletedAt: new Date().toISOString() }
                : report,
            ),
          }));
          setDeleteId(null);
          showToast("体检报告已删除");
        }}
      />
    </>
  );
}

export function ExaminationReportForm() {
  const { data, update } = useStore();
  const { showToast } = useToast();
  const queryId =
    typeof window === "undefined"
      ? null
      : getAppSearchParams().get("id");
  const existing = data.examinationReports.find(
    (report) => report.id === queryId && !report.deletedAt,
  );
  const [reportDate, setReportDate] = useState(
    existing?.reportDate ?? isoDate(),
  );
  const [title, setTitle] = useState(existing?.title ?? "常规体检报告");
  const [hospital, setHospital] = useState(existing?.hospital ?? "");
  const [doctor, setDoctor] = useState(existing?.doctor ?? "");
  const [fileName, setFileName] = useState(existing?.fileName ?? "");
  const [note, setNote] = useState(existing?.note ?? "");
  const [drafts, setDrafts] = useState<MetricDraft[]>(() =>
    existing ? existing.metrics.map(draftFromMetric) : emptyDrafts(),
  );
  const [error, setError] = useState("");
  const parsedMetrics = useMemo(() => metricsFromDrafts(drafts), [drafts]);
  const previewAnalysis = useMemo(
    () =>
      parsedMetrics.length
        ? buildExaminationAnalysis(
            { reportDate, metrics: parsedMetrics },
            data.examinationReports.filter(
              (report) => report.id !== existing?.id && !report.deletedAt,
            ),
          )
        : null,
    [data.examinationReports, existing?.id, parsedMetrics, reportDate],
  );

  const updateDraft = (
    id: string,
    field: keyof MetricDraft,
    value: string,
  ) => {
    setDrafts((current) =>
      current.map((draft) =>
        draft.id === id ? { ...draft, [field]: value } : draft,
      ),
    );
  };

  const save = () => {
    const result = reportSchema.safeParse({
      reportDate,
      title,
      hospital,
      metrics: parsedMetrics,
    });
    if (!result.success) {
      setError(result.error.issues[0]?.message || "请检查表单内容");
      return;
    }

    const timestamp = new Date().toISOString();
    const report: ExaminationReport = {
      id: existing?.id ?? uid(),
      reportDate,
      title: title.trim(),
      hospital: hospital.trim(),
      doctor: doctor.trim(),
      fileName: fileName || undefined,
      note: note.trim(),
      metrics: result.data.metrics,
      analysis: buildExaminationAnalysis(
        { reportDate, metrics: result.data.metrics },
        data.examinationReports.filter(
          (item) => item.id !== existing?.id && !item.deletedAt,
        ),
      ),
      createdAt: existing?.createdAt ?? timestamp,
      updatedAt: timestamp,
    };

    update((current) => ({
      ...current,
      examinationReports: [
        ...current.examinationReports.filter((item) => item.id !== report.id),
        report,
      ],
    }));
    showToast(existing ? "体检报告和分析已更新" : "体检报告已保存，分析已生成");
    navigate(`/reports/detail?id=${report.id}`);
  };

  return (
    <>
      <PageHeader
        title={existing ? "修改体检报告" : "添加体检报告"}
        description="请照着原报告逐项填写。参考范围优先使用报告上印刷的范围。"
        backHref="/reports"
      />

      {error ? (
        <div className="urgent-alert" role="alert">
          <AlertTriangle aria-hidden="true" />
          <div>
            <strong>还有内容需要检查</strong>
            <p>{error}</p>
          </div>
        </div>
      ) : null}

      <Card>
        <form
          className="form-stack"
          onSubmit={(event) => {
            event.preventDefault();
            save();
          }}
        >
          <div className="form-grid">
            <Field label="体检日期">
              <Input
                type="date"
                value={reportDate}
                onChange={(event) => setReportDate(event.target.value)}
                required
              />
            </Field>
            <Field label="报告名称">
              <Input
                value={title}
                onChange={(event) => setTitle(event.target.value)}
                placeholder="例如：年度常规体检"
                required
              />
            </Field>
            <Field label="体检机构">
              <Input
                value={hospital}
                onChange={(event) => setHospital(event.target.value)}
                placeholder="请填写报告上的机构名称"
                required
              />
            </Field>
            <Field label="医生或科室" hint="可不填写">
              <Input
                value={doctor}
                onChange={(event) => setDoctor(event.target.value)}
                placeholder="例如：健康管理中心"
              />
            </Field>
          </div>
          <Field
            label="原报告文件"
            hint="演示模式只保存文件名，不会上传文件。正式版已预留私有文件存储接口。"
          >
            <Input
              type="file"
              accept=".pdf,image/*"
              onChange={(event) =>
                setFileName(event.target.files?.[0]?.name ?? "")
              }
            />
          </Field>
          {fileName ? <p className="selected-file">已选择：{fileName}</p> : null}

          <div className="metric-form-heading">
            <div>
              <h2>体检指标</h2>
              <p>
                只填写报告中有的项目。数值、单位和参考范围需要与原报告一致。
              </p>
            </div>
            <Button
              type="button"
              variant="secondary"
              icon={Plus}
              onClick={() =>
                setDrafts((current) => [
                  ...current,
                  {
                    id: uid(),
                    key: `custom-${uid()}`,
                    name: "",
                    value: "",
                    unit: "",
                    referenceMin: "",
                    referenceMax: "",
                    custom: true,
                  },
                ])
              }
            >
              添加其他指标
            </Button>
          </div>

          <div className="metric-entry-list">
            {drafts.map((draft) => (
              <fieldset className="metric-entry" key={draft.id}>
                <legend>{draft.custom ? "自定义指标" : draft.name}</legend>
                <div className="metric-entry-grid">
                  {draft.custom ? (
                    <Field label="指标名称">
                      <Input
                        value={draft.name}
                        onChange={(event) =>
                          updateDraft(draft.id, "name", event.target.value)
                        }
                        placeholder="照报告填写"
                      />
                    </Field>
                  ) : null}
                  <Field label="检查结果">
                    <Input
                      inputMode="decimal"
                      type="number"
                      step="any"
                      value={draft.value}
                      onChange={(event) =>
                        updateDraft(draft.id, "value", event.target.value)
                      }
                      placeholder="没有此项可留空"
                    />
                  </Field>
                  <Field label="单位">
                    <Input
                      value={draft.unit}
                      onChange={(event) =>
                        updateDraft(draft.id, "unit", event.target.value)
                      }
                      placeholder="照报告填写"
                    />
                  </Field>
                  <Field label="参考范围下限" hint="报告未提供可留空">
                    <Input
                      inputMode="decimal"
                      type="number"
                      step="any"
                      value={draft.referenceMin}
                      onChange={(event) =>
                        updateDraft(
                          draft.id,
                          "referenceMin",
                          event.target.value,
                        )
                      }
                      placeholder="最低值"
                    />
                  </Field>
                  <Field label="参考范围上限" hint="报告未提供可留空">
                    <Input
                      inputMode="decimal"
                      type="number"
                      step="any"
                      value={draft.referenceMax}
                      onChange={(event) =>
                        updateDraft(
                          draft.id,
                          "referenceMax",
                          event.target.value,
                        )
                      }
                      placeholder="最高值"
                    />
                  </Field>
                </div>
                {draft.custom ? (
                  <Button
                    type="button"
                    variant="quiet"
                    icon={Trash2}
                    onClick={() =>
                      setDrafts((current) =>
                        current.filter((item) => item.id !== draft.id),
                      )
                    }
                  >
                    移除此指标
                  </Button>
                ) : null}
              </fieldset>
            ))}
          </div>

          {previewAnalysis ? (
            <Card className="analysis-preview" as="div">
              <div className="analysis-card-heading">
                <span className="feature-icon">
                  <Activity aria-hidden="true" />
                </span>
                <div>
                  <span className="card-kicker">实时分析预览</span>
                  <h2>已读取 {parsedMetrics.length} 项指标</h2>
                </div>
              </div>
              <p>{previewAnalysis.summary}</p>
              <div className="analysis-counts">
                <span>
                  <strong>{previewAnalysis.inRangeCount}</strong>
                  参考范围内
                </span>
                <span>
                  <strong>{previewAnalysis.attentionCount}</strong>
                  超出范围
                </span>
                <span>
                  <strong>{previewAnalysis.pendingCount}</strong>
                  待补充范围
                </span>
              </div>
            </Card>
          ) : null}

          <Field label="报告备注" hint="可记录医生原话或下次复查时间">
            <Textarea
              value={note}
              onChange={(event) => setNote(event.target.value)}
              placeholder="请勿自行添加诊断结论"
            />
          </Field>

          <div className="sticky-form-actions">
            <Button type="submit" icon={ClipboardCheck}>
              保存并生成分析
            </Button>
            <Button
              type="button"
              variant="secondary"
              onClick={() => navigate("/reports")}
            >
              取消
            </Button>
          </div>
        </form>
      </Card>
    </>
  );
}

export function ExaminationReportDetail() {
  const { data } = useStore();
  const queryId =
    typeof window === "undefined"
      ? null
      : getAppSearchParams().get("id");
  const report = data.examinationReports.find(
    (item) => item.id === queryId && !item.deletedAt,
  );

  if (!report) {
    return (
      <>
        <PageHeader title="体检报告详情" backHref="/reports" />
        <EmptyState
          icon={FileText}
          title="没有找到这份报告"
          description="报告可能已被删除，请返回体检报告列表。"
        />
      </>
    );
  }

  return (
    <>
      <PageHeader
        title={report.title}
        description={`${formatDate(report.reportDate)}，${report.hospital}`}
        backHref="/reports"
        action={
          <Button
            variant="secondary"
            icon={Pencil}
            onClick={() => navigate(`/reports/add?id=${report.id}`)}
          >
            修改报告
          </Button>
        }
      />

      <Card className="report-source-card">
        <div>
          <span>体检日期</span>
          <strong>{formatDate(report.reportDate)}</strong>
        </div>
        <div>
          <span>体检机构</span>
          <strong>{report.hospital}</strong>
        </div>
        <div>
          <span>医生或科室</span>
          <strong>{report.doctor || "未填写"}</strong>
        </div>
        <div>
          <span>原报告文件</span>
          <strong>{report.fileName || "未保存文件名"}</strong>
        </div>
      </Card>

      <Card className="analysis-detail-card">
        <div className="analysis-card-heading">
          <span className="feature-icon">
            <Activity aria-hidden="true" />
          </span>
          <div>
            <span className="card-kicker">保存后生成的分析</span>
            <h2>本次健康保护提示</h2>
            <p>
              生成时间：
              {new Intl.DateTimeFormat("zh-CN", {
                dateStyle: "medium",
                timeStyle: "short",
              }).format(new Date(report.analysis.generatedAt))}
            </p>
          </div>
        </div>
        <p className="analysis-summary">{report.analysis.summary}</p>
        <div className="analysis-counts">
          <span>
            <strong>{report.analysis.inRangeCount}</strong>
            参考范围内
          </span>
          <span>
            <strong>{report.analysis.attentionCount}</strong>
            超出范围
          </span>
          <span>
            <strong>{report.analysis.pendingCount}</strong>
            待补充范围
          </span>
        </div>
        <div className="protective-actions">
          <h3>建议你接下来这样做</h3>
          <ol>
            <li>先与原报告逐项核对数值、单位和参考范围。</li>
            <li>把本页和原报告一起带给医生，结合症状、病史和用药解释。</li>
            <li>不要仅凭自动分析自行停药、加药、减药或改变剂量。</li>
            <li>
              如原报告标注危急值，或出现明显不适，请及时联系医生或当地紧急医疗服务。
            </li>
          </ol>
        </div>
      </Card>

      <section aria-labelledby="all-metrics-title">
        <div className="section-heading">
          <div>
            <h2 id="all-metrics-title">全部指标和分析</h2>
            <p>共 {report.metrics.length} 项，保留录入时的原始单位和参考范围</p>
          </div>
        </div>
        <div className="analysis-item-list">
          {report.analysis.items.map((analysisItem) => {
            const metric = report.metrics.find(
              (item) => item.id === analysisItem.metricId,
            );
            if (!metric) return null;
            return (
              <Card className="analysis-item" as="article" key={metric.id}>
                <div className="analysis-item-heading">
                  <div>
                    <h3>{metric.name}</h3>
                    <strong className="metric-value">
                      {metric.value} {metric.unit}
                    </strong>
                  </div>
                  <StatusBadge status={analysisItem.status} />
                </div>
                <dl>
                  <div>
                    <dt>报告参考范围</dt>
                    <dd>
                      {metric.referenceMin === undefined &&
                      metric.referenceMax === undefined
                        ? "未填写"
                        : `${metric.referenceMin ?? "未填"} 至 ${
                            metric.referenceMax ?? "未填"
                          } ${metric.unit}`}
                    </dd>
                  </div>
                  <div>
                    <dt>上次结果</dt>
                    <dd>
                      {analysisItem.previousValue === undefined
                        ? "首次记录"
                        : `${analysisItem.previousValue} ${metric.unit}`}
                    </dd>
                  </div>
                  <div>
                    <dt>本次变化</dt>
                    <dd>
                      {analysisItem.change === undefined
                        ? "首次记录"
                        : `${analysisItem.change >= 0 ? "+" : ""}${
                            analysisItem.change
                          } ${metric.unit}`}
                    </dd>
                  </div>
                </dl>
                <p>{analysisItem.message}</p>
                <div className="item-suggestion">
                  <ShieldCheck aria-hidden="true" />
                  <span>{analysisItem.suggestion}</span>
                </div>
              </Card>
            );
          })}
        </div>
      </section>

      {report.note ? (
        <Card>
          <h2>报告备注</h2>
          <p>{report.note}</p>
        </Card>
      ) : null}

      <Card className="safety-note">
        <AlertTriangle aria-hidden="true" />
        <div>
          <h2>这不是医学诊断</h2>
          <p>
            自动分析只用于整理和提醒。单次检查结果不能独立说明疾病，
            请由专业医生结合完整病史和检查方法判断。
          </p>
        </div>
      </Card>
    </>
  );
}
