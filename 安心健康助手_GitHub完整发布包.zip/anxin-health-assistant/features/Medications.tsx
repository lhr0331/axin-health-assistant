"use client";

import {
  AlarmClock,
  BellRing,
  Check,
  Clock3,
  History,
  Pill,
  Plus,
  RotateCcw,
  SkipForward,
  Trash2,
} from "lucide-react";
import { useMemo, useState } from "react";
import { navigate } from "@/components/AppShell";
import {
  Button,
  Card,
  ChoiceGroup,
  ConfirmDialog,
  EmptyState,
  Field,
  Input,
  PageHeader,
  Progress,
  Select,
  StatusBadge,
  Textarea,
  useToast,
} from "@/components/ui";
import { isoDate, timeNow, uid } from "@/lib/date";
import { getAppSearchParams } from "@/lib/app-location";
import { useStore } from "@/lib/store";
import type { Medication } from "@/lib/types";

export function MedicationList() {
  const { data, update } = useStore();
  const { showToast } = useToast();
  const [deleting, setDeleting] = useState<Medication | null>(null);
  const medications = data.medications.filter((item) => !item.deletedAt);
  return (
    <>
      <PageHeader
        title="药品管理"
        description="管理正在服用的药品和每天的提醒时间"
        action={
          <Button icon={Plus} onClick={() => navigate("/medications/add")}>
            添加药品
          </Button>
        }
      />
      <div className="subnav">
        <a href="/medications/today" data-nav>
          <AlarmClock aria-hidden="true" />
          今日用药
        </a>
        <a href="/medications/history" data-nav>
          <History aria-hidden="true" />
          用药历史
        </a>
      </div>
      {medications.length ? (
        <div className="record-list">
          {medications.map((medication) => (
            <Card key={medication.id} className="med-card">
              <div className="med-icon">
                <Pill aria-hidden="true" />
              </div>
              <div className="med-info">
                <div className="med-title-row">
                  <h2>{medication.name}</h2>
                  <StatusBadge
                    status={medication.reminderEnabled ? "提醒已开启" : "提醒已关闭"}
                  />
                </div>
                <p>
                  每次 {medication.dose} {medication.unit}，{medication.method}，
                  {medication.mealRequirement}
                </p>
                <div className="time-tags">
                  {medication.times.map((time) => (
                    <span key={time}>
                      <Clock3 aria-hidden="true" />
                      {time}
                    </span>
                  ))}
                </div>
              </div>
              <div className="record-actions">
                <Button
                  variant="secondary"
                  onClick={() => navigate(`/medications/add?id=${medication.id}`)}
                >
                  修改
                </Button>
                <Button
                  variant="quiet"
                  icon={Trash2}
                  onClick={() => setDeleting(medication)}
                >
                  删除
                </Button>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={Pill}
          title="还没有添加药品"
          description="添加药品、用量和时间后，今日用药会自动生成任务。"
          action={
            <Button icon={Plus} onClick={() => navigate("/medications/add")}>
              添加第一个药品
            </Button>
          }
        />
      )}
      <ConfirmDialog
        open={Boolean(deleting)}
        title="确认删除这个药品？"
        description="删除后将不再生成新的服药任务，过去的服药记录仍会保留。"
        onCancel={() => setDeleting(null)}
        onConfirm={() => {
          if (!deleting) return;
          update((current) => ({
            ...current,
            medications: current.medications.map((item) =>
              item.id === deleting.id
                ? { ...item, deletedAt: new Date().toISOString() }
                : item,
            ),
          }));
          setDeleting(null);
          showToast("药品已删除");
        }}
      />
    </>
  );
}

export function MedicationForm() {
  const { data, update } = useStore();
  const { showToast } = useToast();
  const queryId =
    typeof window === "undefined"
      ? null
      : getAppSearchParams().get("id");
  const existing = data.medications.find((item) => item.id === queryId);
  const [form, setForm] = useState<Medication>(
    existing || {
      id: uid(),
      name: "",
      dose: "1",
      unit: "片",
      method: "口服",
      times: ["08:00"],
      startDate: isoDate(),
      endDate: "",
      mealRequirement: "饭后",
      purpose: "",
      doctorInstructions: "",
      note: "",
      reminderEnabled: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
  );

  const save = () => {
    if (!form.name.trim()) {
      showToast("请填写药品名称", "error");
      return;
    }
    if (!form.times.length || form.times.some((time) => !time)) {
      showToast("请至少填写一个完整的服用时间", "error");
      return;
    }
    update((current) => ({
      ...current,
      medications: [
        ...current.medications.filter((item) => item.id !== form.id),
        { ...form, updatedAt: new Date().toISOString() },
      ],
    }));
    showToast("药品信息已保存");
    navigate("/medications");
  };

  return (
    <>
      <PageHeader
        title={existing ? "修改药品" : "添加药品"}
        description="请按照药品包装或医生说明填写，不要自行改变用药方案。"
        backHref="/medications"
      />
      <Card>
        <form
          className="form-stack"
          onSubmit={(event) => {
            event.preventDefault();
            save();
          }}
        >
          <div className="form-grid">
            <Field label="药品名称">
              <Input
                value={form.name}
                placeholder="例如：降压药"
                onChange={(event) =>
                  setForm({ ...form, name: event.target.value })
                }
                required
              />
            </Field>
            <Field label="每次用量">
              <Input
                inputMode="decimal"
                value={form.dose}
                onChange={(event) =>
                  setForm({ ...form, dose: event.target.value })
                }
                required
              />
            </Field>
          </div>
          <Field label="用量单位">
            <ChoiceGroup
              options={["片", "粒", "袋", "毫升", "滴", "支", "其他"]}
              value={form.unit}
              onChange={(value) => setForm({ ...form, unit: value as string })}
              ariaLabel="选择用量单位"
            />
          </Field>
          <div className="form-grid">
            <Field label="服用方式">
              <Select
                value={form.method}
                onChange={(event) =>
                  setForm({ ...form, method: event.target.value })
                }
              >
                {["口服", "外用", "注射", "滴眼", "其他"].map((item) => (
                  <option key={item}>{item}</option>
                ))}
              </Select>
            </Field>
            <Field label="服用要求">
              <Select
                value={form.mealRequirement}
                onChange={(event) =>
                  setForm({ ...form, mealRequirement: event.target.value })
                }
              >
                {["饭前", "饭后", "随餐", "空腹", "无特别要求"].map((item) => (
                  <option key={item}>{item}</option>
                ))}
              </Select>
            </Field>
          </div>
          <fieldset className="fieldset">
            <legend>每日服用时间</legend>
            <p>可以添加多个时间，例如早上 08:00、晚上 20:00。</p>
            <div className="time-list">
              {form.times.map((time, index) => (
                <div key={`${index}-${time}`}>
                  <Input
                    type="time"
                    aria-label={`第 ${index + 1} 个服用时间`}
                    value={time}
                    onChange={(event) => {
                      const times = [...form.times];
                      times[index] = event.target.value;
                      setForm({ ...form, times });
                    }}
                  />
                  {form.times.length > 1 ? (
                    <Button
                      type="button"
                      variant="quiet"
                      onClick={() =>
                        setForm({
                          ...form,
                          times: form.times.filter((_, itemIndex) => itemIndex !== index),
                        })
                      }
                    >
                      移除
                    </Button>
                  ) : null}
                </div>
              ))}
              <Button
                type="button"
                variant="secondary"
                icon={Plus}
                onClick={() => setForm({ ...form, times: [...form.times, ""] })}
              >
                添加另一个时间
              </Button>
            </div>
          </fieldset>
          <div className="form-grid">
            <Field label="开始日期">
              <Input
                type="date"
                value={form.startDate}
                onChange={(event) =>
                  setForm({ ...form, startDate: event.target.value })
                }
              />
            </Field>
            <Field label="结束日期" hint="长期服用可不填">
              <Input
                type="date"
                value={form.endDate}
                onChange={(event) =>
                  setForm({ ...form, endDate: event.target.value })
                }
              />
            </Field>
          </div>
          <div className="form-grid">
            <Field label="药品用途">
              <Input
                value={form.purpose}
                placeholder="例如：帮助控制血压"
                onChange={(event) =>
                  setForm({ ...form, purpose: event.target.value })
                }
              />
            </Field>
            <Field label="医生说明">
              <Input
                value={form.doctorInstructions}
                onChange={(event) =>
                  setForm({ ...form, doctorInstructions: event.target.value })
                }
              />
            </Field>
          </div>
          <Field label="备注">
            <Textarea
              value={form.note}
              onChange={(event) => setForm({ ...form, note: event.target.value })}
            />
          </Field>
          <label className="toggle-row">
            <span>
              <strong>启用到点提醒</strong>
              <small>需要先在通知设置中允许浏览器通知</small>
            </span>
            <input
              type="checkbox"
              checked={form.reminderEnabled}
              onChange={(event) =>
                setForm({ ...form, reminderEnabled: event.target.checked })
              }
            />
          </label>
          <div className="sticky-form-actions">
            <Button type="submit" icon={Pill}>
              保存药品
            </Button>
            <Button
              type="button"
              variant="secondary"
              onClick={() => navigate("/medications")}
            >
              取消
            </Button>
          </div>
        </form>
      </Card>
    </>
  );
}

type TodayTask = {
  medication: Medication;
  scheduledTime: string;
  status: "待服用" | "已服用" | "已跳过" | "已漏服";
  actualTime?: string;
};

export function TodayMedication() {
  const { data, update } = useStore();
  const { showToast } = useToast();
  const [confirmUndo, setConfirmUndo] = useState<TodayTask | null>(null);
  const [snoozeTask, setSnoozeTask] = useState<TodayTask | null>(null);
  const today = isoDate();
  const tasks = useMemo<TodayTask[]>(() => {
    return data.medications
      .filter(
        (item) =>
          !item.deletedAt &&
          item.startDate <= today &&
          (!item.endDate || item.endDate >= today),
      )
      .flatMap((medication) =>
        medication.times.map((scheduledTime) => {
          const log = data.medicationLogs.find(
            (item) =>
              item.medicationId === medication.id &&
              item.date === today &&
              item.scheduledTime === scheduledTime,
          );
          return {
            medication,
            scheduledTime,
            status:
              log?.status ||
              (scheduledTime < timeNow() ? "已漏服" : "待服用"),
            actualTime: log?.actualTime,
          };
        }),
      )
      .sort((a, b) => a.scheduledTime.localeCompare(b.scheduledTime));
  }, [data.medications, data.medicationLogs, today]);
  const completed = tasks.filter((task) => task.status === "已服用").length;

  const setStatus = (
    task: TodayTask,
    status: "待服用" | "已服用" | "已跳过",
  ) => {
    update((current) => ({
      ...current,
      medicationLogs: [
        ...current.medicationLogs.filter(
          (item) =>
            !(
              item.medicationId === task.medication.id &&
              item.date === today &&
              item.scheduledTime === task.scheduledTime
            ),
        ),
        {
          id: uid(),
          medicationId: task.medication.id,
          date: today,
          scheduledTime: task.scheduledTime,
          status,
          actualTime: status === "已服用" ? timeNow() : undefined,
        },
      ],
    }));
    showToast(
      status === "已服用"
        ? "已记录实际服药时间"
        : status === "已跳过"
          ? "已跳过本次服药"
          : "服药任务已恢复为待服用",
    );
  };

  return (
    <>
      <PageHeader
        title="今日用药"
        description={`${today}，按时间顺序完成今天的服药安排`}
        action={
          <Button
            variant="secondary"
            icon={Pill}
            onClick={() => navigate("/medications")}
          >
            管理药品
          </Button>
        }
      />
      <Card className="today-progress">
        <div>
          <span className="card-kicker">今日进度</span>
          <h2>
            今天需要服药 {tasks.length} 次，已经完成 {completed} 次
          </h2>
        </div>
        <Progress value={completed} max={tasks.length} label="今日服药进度" />
      </Card>
      {tasks.length ? (
        <div className="timeline">
          {tasks.map((task) => (
            <Card
              key={`${task.medication.id}-${task.scheduledTime}`}
              className={`med-task task-${task.status}`}
            >
              <div className="task-time">
                <Clock3 aria-hidden="true" />
                <strong>{task.scheduledTime}</strong>
              </div>
              <div className="task-body">
                <div className="med-title-row">
                  <h2>{task.medication.name}</h2>
                  <StatusBadge status={task.status} />
                </div>
                <p>
                  每次 {task.medication.dose} {task.medication.unit}，
                  {task.medication.mealRequirement}，{task.medication.method}
                </p>
                {task.actualTime ? (
                  <small>实际服药时间：{task.actualTime}</small>
                ) : null}
                {task.status === "待服用" || task.status === "已漏服" ? (
                  <div className="task-actions">
                    <Button
                      variant="success"
                      icon={Check}
                      onClick={() => setStatus(task, "已服用")}
                    >
                      已服用
                    </Button>
                    <Button
                      variant="secondary"
                      icon={BellRing}
                      onClick={() => setSnoozeTask(task)}
                    >
                      稍后提醒
                    </Button>
                    <Button
                      variant="quiet"
                      icon={SkipForward}
                      onClick={() => setStatus(task, "已跳过")}
                    >
                      跳过本次
                    </Button>
                  </div>
                ) : (
                  <Button
                    variant="quiet"
                    icon={RotateCcw}
                    onClick={() => setConfirmUndo(task)}
                  >
                    撤销本次记录
                  </Button>
                )}
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={Pill}
          title="今天没有服药安排"
          description="添加药品和服用时间后，任务会显示在这里。"
          action={
            <Button icon={Plus} onClick={() => navigate("/medications/add")}>
              添加药品
            </Button>
          }
        />
      )}
      {snoozeTask ? (
        <div className="dialog-backdrop" role="presentation">
          <div className="dialog" role="dialog" aria-modal="true">
            <BellRing className="dialog-icon" aria-hidden="true" />
            <h2>多久后再提醒？</h2>
            <p>{snoozeTask.medication.name}</p>
            <div className="snooze-grid">
              {[10, 20, 30, 60].map((minutes) => (
                <Button
                  key={minutes}
                  variant="secondary"
                  onClick={() => {
                    const reminderKey = `${today}:${snoozeTask.medication.id}:${snoozeTask.scheduledTime}`;
                    const snoozeUntil = new Date(
                      Date.now() + minutes * 60_000,
                    ).toISOString();
                    update((current) => ({
                      ...current,
                      notificationLogs: current.notificationLogs.filter(
                        (item) => item !== reminderKey,
                      ),
                      medicationLogs: [
                        ...current.medicationLogs.filter(
                          (item) =>
                            !(
                              item.medicationId === snoozeTask.medication.id &&
                              item.date === today &&
                              item.scheduledTime === snoozeTask.scheduledTime
                            ),
                        ),
                        {
                          id: uid(),
                          medicationId: snoozeTask.medication.id,
                          date: today,
                          scheduledTime: snoozeTask.scheduledTime,
                          status: "待服用",
                          snoozeUntil,
                        },
                      ],
                    }));
                    showToast(
                      `将在 ${minutes === 60 ? "1 小时" : `${minutes} 分钟`}后应用内提醒`,
                    );
                    setSnoozeTask(null);
                  }}
                >
                  {minutes === 60 ? "1 小时后" : `${minutes} 分钟后`}
                </Button>
              ))}
            </div>
            <Button variant="quiet" onClick={() => setSnoozeTask(null)}>
              取消
            </Button>
          </div>
        </div>
      ) : null}
      <ConfirmDialog
        open={Boolean(confirmUndo)}
        title="确认撤销这次服药记录？"
        description="撤销后，这项任务会恢复为待服用。请确认实际情况后再操作。"
        confirmText="确认撤销"
        onCancel={() => setConfirmUndo(null)}
        onConfirm={() => {
          if (!confirmUndo) return;
          setStatus(confirmUndo, "待服用");
          setConfirmUndo(null);
        }}
      />
    </>
  );
}

export function MedicationHistory() {
  const { data } = useStore();
  const recentDates = Array.from({ length: 7 }, (_, index) => {
    const date = new Date();
    date.setDate(date.getDate() - index);
    return isoDate(date);
  });
  return (
    <>
      <PageHeader
        title="用药历史"
        description="最近 7 天的简单完成情况"
        backHref="/medications/today"
      />
      <div className="week-list">
        {recentDates.map((date) => {
          const total = data.medications
            .filter((item) => !item.deletedAt)
            .reduce((sum, item) => sum + item.times.length, 0);
          const completed = data.medicationLogs.filter(
            (item) => item.date === date && item.status === "已服用",
          ).length;
          return (
            <Card key={date} className="week-row">
              <div>
                <strong>{date}</strong>
                <span>{date === isoDate() ? "今天" : "过去日期"}</span>
              </div>
              <Progress
                value={completed}
                max={total}
                label={`已完成 ${completed} 次，共 ${total} 次`}
              />
            </Card>
          );
        })}
      </div>
      <Card className="info-note">
        <p>
          这里仅展示记录完成情况，不分析药效，也不会评价或改变医生给出的用药方案。
        </p>
      </Card>
    </>
  );
}
