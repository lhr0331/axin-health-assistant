-- 安心健康助手 Supabase / PostgreSQL 初始化脚本
-- 在全新项目的 SQL Editor 中执行。所有业务数据按 auth.uid() 隔离。

create extension if not exists pgcrypto;

create or replace function public.set_updated_at()
returns trigger language plpgsql security invoker set search_path = public as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create table if not exists public.user_profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  display_name text,
  gender text,
  birth_date date,
  phone text,
  emergency_name text,
  emergency_phone text,
  blood_type text,
  allergies text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.health_records (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  recorded_date date not null,
  recorded_time time not null,
  overall_status text not null check (overall_status in ('很好','正常','不太舒服','很不舒服')),
  spirit_status text,
  sleep_status text,
  pain_level text,
  pain_location text,
  symptoms text[] not null default '{}',
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create index if not exists health_records_user_date_idx
  on public.health_records(user_id, recorded_date desc) where deleted_at is null;

create table if not exists public.diseases (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  diagnosis_date date,
  current_status text not null check (current_status in ('治疗中','稳定','需要复查','已结束')),
  hospital text,
  doctor text,
  precautions text,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create index if not exists diseases_user_status_idx
  on public.diseases(user_id, current_status) where deleted_at is null;

create table if not exists public.medications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  dose numeric(10,2) not null check (dose > 0),
  dose_unit text not null,
  administration_method text not null,
  daily_frequency integer not null default 1 check (daily_frequency > 0),
  start_date date not null,
  end_date date,
  meal_requirement text,
  purpose text,
  doctor_instructions text,
  notes text,
  reminder_enabled boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  constraint medication_date_order check (end_date is null or end_date >= start_date)
);

create index if not exists medications_user_active_idx
  on public.medications(user_id, start_date, end_date) where deleted_at is null;

create table if not exists public.medication_schedules (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  medication_id uuid not null references public.medications(id) on delete cascade,
  scheduled_time time not null,
  timezone text not null default 'Asia/Shanghai',
  enabled boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (medication_id, scheduled_time)
);

create index if not exists medication_schedules_user_time_idx
  on public.medication_schedules(user_id, scheduled_time) where deleted_at is null;

create table if not exists public.medication_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  medication_id uuid not null references public.medications(id) on delete cascade,
  schedule_id uuid references public.medication_schedules(id) on delete set null,
  scheduled_date date not null,
  scheduled_time time not null,
  status text not null check (status in ('待服用','已服用','已跳过','已漏服')),
  actual_taken_at timestamptz,
  skipped_reason text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (user_id, medication_id, scheduled_date, scheduled_time)
);

create index if not exists medication_logs_user_date_idx
  on public.medication_logs(user_id, scheduled_date desc) where deleted_at is null;

create table if not exists public.reminders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  source_type text not null check (source_type in ('medication','memo','other')),
  source_id uuid,
  scheduled_at timestamptz not null,
  channel text not null default 'browser' check (channel in ('browser','sms','wechat','native')),
  status text not null default 'pending' check (status in ('pending','sent','failed','cancelled')),
  snoozed_until timestamptz,
  deduplication_key text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (user_id, deduplication_key)
);

create index if not exists reminders_pending_idx
  on public.reminders(scheduled_at) where status = 'pending' and deleted_at is null;

create table if not exists public.memos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  category text not null,
  memo_date date not null,
  memo_time time,
  reminder_enabled boolean not null default false,
  notes text,
  completed boolean not null default false,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create index if not exists memos_user_date_idx
  on public.memos(user_id, memo_date desc) where deleted_at is null;

create table if not exists public.meal_records (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  meal_date date not null,
  meal_time time not null,
  meal_type text not null check (meal_type in ('早餐','午餐','晚餐','加餐','饮水')),
  food_names text,
  portion text,
  water_ml integer not null default 0 check (water_ml >= 0),
  notes text,
  photo_storage_path text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create index if not exists meal_records_user_date_idx
  on public.meal_records(user_id, meal_date desc) where deleted_at is null;

create table if not exists public.examination_reports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  report_date date not null,
  title text not null,
  hospital text not null,
  doctor text,
  file_storage_path text,
  notes text,
  metrics jsonb not null default '[]'::jsonb,
  analysis jsonb not null default '{}'::jsonb,
  analysis_generated_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  constraint examination_reports_metrics_array
    check (jsonb_typeof(metrics) = 'array')
);

create index if not exists examination_reports_user_date_idx
  on public.examination_reports(user_id, report_date desc)
  where deleted_at is null;

create table if not exists public.notification_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  reminder_id uuid references public.reminders(id) on delete set null,
  channel text not null,
  deduplication_key text not null,
  provider_message_id text,
  delivery_status text not null,
  error_code text,
  sent_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz,
  unique (user_id, deduplication_key)
);

create table if not exists public.user_settings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  large_text boolean not null default false,
  notifications_enabled boolean not null default false,
  reminder_sound boolean not null default true,
  locale text not null default 'zh-CN',
  timezone text not null default 'Asia/Shanghai',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  action text not null,
  entity_type text not null,
  entity_id uuid,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  deleted_at timestamptz
);

-- 自动更新时间戳
do $$
declare
  table_name text;
begin
  foreach table_name in array array[
    'user_profiles','health_records','diseases','medications',
    'medication_schedules','medication_logs','reminders','memos',
    'meal_records','examination_reports','notification_logs',
    'user_settings','audit_logs'
  ]
  loop
    execute format('drop trigger if exists set_%I_updated_at on public.%I', table_name, table_name);
    execute format(
      'create trigger set_%I_updated_at before update on public.%I for each row execute function public.set_updated_at()',
      table_name, table_name
    );
  end loop;
end $$;

-- 新用户自动创建个人设置
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.user_profiles (user_id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'name', '安心用户'))
  on conflict (user_id) do nothing;
  insert into public.user_settings (user_id)
  values (new.id)
  on conflict (user_id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- 行级权限：每个用户只能访问自己的数据
do $$
declare
  table_name text;
begin
  foreach table_name in array array[
    'user_profiles','health_records','diseases','medications',
    'medication_schedules','medication_logs','reminders','memos',
    'meal_records','examination_reports','notification_logs',
    'user_settings','audit_logs'
  ]
  loop
    execute format('alter table public.%I enable row level security', table_name);
    execute format('drop policy if exists "Users manage own rows" on public.%I', table_name);
    execute format(
      'create policy "Users manage own rows" on public.%I for all using (auth.uid() = user_id) with check (auth.uid() = user_id)',
      table_name
    );
  end loop;
end $$;

-- 存储建议：在 Supabase 控制台创建私有 meal-photos 和 examination-reports 桶。
-- 对 storage.objects 设置 user_id 文件夹前缀策略，并通过短时签名 URL 读取。
-- 体检报告属于敏感健康信息，不允许放入公开桶或交给第三方分析服务。
