import { readFile, writeFile, mkdir } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";

const projectRoot = path.resolve(fileURLToPath(new URL("..", import.meta.url)));
const buildRoot = path.join(projectRoot, "release", "offline-build");
const sourceHtmlPath = path.join(buildRoot, "offline", "index.html");
const releaseRoot = path.join(projectRoot, "release");
const outputHtmlPath = path.join(releaseRoot, "安心健康助手_安卓离线版.html");

let html = await readFile(sourceHtmlPath, "utf8");

const stylesheetPattern =
  /<link rel="stylesheet" crossorigin href="([^"]+)">/g;
for (const match of [...html.matchAll(stylesheetPattern)]) {
  const assetPath = path.resolve(path.dirname(sourceHtmlPath), match[1]);
  const css = await readFile(assetPath, "utf8");
  html = html.replace(match[0], () => `<style>${css}</style>`);
}

const scriptPattern =
  /<script type="module" crossorigin src="([^"]+)"><\/script>/g;
for (const match of [...html.matchAll(scriptPattern)]) {
  const assetPath = path.resolve(path.dirname(sourceHtmlPath), match[1]);
  const javascript = (await readFile(assetPath, "utf8")).replace(
    /<\/script/gi,
    "<\\/script",
  );
  html = html.replace(
    match[0],
    () => `<script type="module">${javascript}</script>`,
  );
}

await mkdir(releaseRoot, { recursive: true });
await writeFile(outputHtmlPath, html, "utf8");
console.log(outputHtmlPath);
