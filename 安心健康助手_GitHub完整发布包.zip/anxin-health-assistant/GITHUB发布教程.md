# 安心健康助手 GitHub 正式发布教程

本整合包已经准备好 GitHub Pages 所需的 `docs/index.html`。不需要在 GitHub
服务器安装 Node.js，也不需要填写数据库密钥。

## 一、创建公共仓库

1. 登录 [GitHub](https://github.com/)。
2. 点击右上角 `+`，选择 `New repository`。
3. Repository name 填写：`anxin-health-assistant`。
4. Description 可填写：`面向中老年用户的适老化健康管理应用`。
5. 选择 `Public`。
6. 不要勾选自动创建 README、.gitignore 或 License。
7. 点击 `Create repository`。

## 二、上传整合包

1. 解压 `安心健康助手_GitHub完整发布包.zip`。
2. 进入刚创建的空仓库。
3. 点击 `uploading an existing file`；如果仓库不是空的，点击
   `Add file` → `Upload files`。
4. 把解压后文件夹里面的全部文件和文件夹拖入上传区域。
   不要直接上传 ZIP，因为 GitHub 不会自动解压 ZIP。
5. 等待文件列表全部出现。
6. Commit message 填写：`Initial release of 安心健康助手`。
7. 选择提交到 `main` 分支，然后点击 `Commit changes`。

整合包中的单个文件均小于 GitHub 网页上传的 25 MiB 限制，文件总数也控制在
网页批量上传范围内。

## 三、开启 GitHub Pages

1. 进入仓库顶部的 `Settings`。
2. 左侧点击 `Pages`。
3. 在 `Build and deployment` 下：
   - Source 选择 `Deploy from a branch`。
   - Branch 选择 `main`。
   - Folder 选择 `/docs`。
4. 点击 `Save`。
5. 等待约 1 至 10 分钟，刷新 Pages 设置页面。

发布完成后的地址通常是：

```text
https://你的GitHub用户名.github.io/anxin-health-assistant/
```

## 四、在安卓和微信中使用

1. 把 GitHub Pages 地址发送给客户。
2. 客户可先在微信中点击地址。
3. 如果微信限制本地存储或通知，点击右上角菜单，选择“在浏览器打开”，使用
   Chrome。
4. 数据保存在客户当前浏览器中。清除浏览器数据、更换手机或更换浏览器后，
   数据不会自动同步。

## 五、以后更新

修改项目后，在电脑项目目录执行：

```bash
npm install
npm run build:offline
```

然后把新生成的 `release/安心健康助手_安卓离线版.html` 重命名为
`index.html`，替换 GitHub 仓库里的 `docs/index.html` 并提交。GitHub Pages
会自动重新发布。

## 六、重要限制

- 当前 GitHub Pages 版本使用浏览器 localStorage，不是正式云数据库。
- 浏览器关闭后，后台服药通知可能延迟或不出现。
- 不要把 `.env.local`、Supabase 管理员密钥、用户真实健康数据上传到 GitHub。
- 本应用用于记录个人健康信息，不提供医学诊断。
