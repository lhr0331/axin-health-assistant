import { isoDate } from "./date";
import { buildExaminationAnalysis } from "./exam-analysis";
import type {
  AppData,
  ExaminationMetric,
  ExaminationReport,
} from "./types";

const now = new Date().toISOString();
const today = isoDate();

const metric = (
  reportId: string,
  key: string,
  name: string,
  value: number,
  unit: string,
  referenceMin?: number,
  referenceMax?: number,
): ExaminationMetric => ({
  id: `${reportId}-${key}`,
  key,
  name,
  value,
  unit,
  referenceMin,
  referenceMax,
});

const examinationSeeds: Array<
  Omit<ExaminationReport, "analysis" | "createdAt" | "updatedAt">
> = [
  {
    id: "exam-demo-2025-10",
    reportDate: "2025-10-18",
    title: "秋季常规体检（演示）",
    hospital: "安心体检中心（虚拟）",
    doctor: "演示医生",
    fileName: "演示体检报告-2025-10.pdf",
    note: "本报告及全部数值均为虚拟演示数据。",
    metrics: [
      metric("exam-demo-2025-10", "systolic-bp", "收缩压", 142, "mmHg", 90, 139),
      metric("exam-demo-2025-10", "fasting-glucose", "空腹血糖", 5.7, "mmol/L", 3.9, 6.1),
      metric("exam-demo-2025-10", "total-cholesterol", "总胆固醇", 5.4, "mmol/L", 3, 5.2),
      metric("exam-demo-2025-10", "uric-acid", "尿酸", 425, "μmol/L", 202, 416),
      metric("exam-demo-2025-10", "creatinine", "肌酐", 83, "μmol/L", 45, 104),
      metric("exam-demo-2025-10", "weight", "体重", 68.5, "kg"),
    ],
  },
  {
    id: "exam-demo-2026-01",
    reportDate: "2026-01-20",
    title: "冬季复查（演示）",
    hospital: "安心体检中心（虚拟）",
    doctor: "演示医生",
    fileName: "演示体检报告-2026-01.pdf",
    note: "本报告及全部数值均为虚拟演示数据。",
    metrics: [
      metric("exam-demo-2026-01", "systolic-bp", "收缩压", 138, "mmHg", 90, 139),
      metric("exam-demo-2026-01", "fasting-glucose", "空腹血糖", 5.9, "mmol/L", 3.9, 6.1),
      metric("exam-demo-2026-01", "total-cholesterol", "总胆固醇", 5.2, "mmol/L", 3, 5.2),
      metric("exam-demo-2026-01", "uric-acid", "尿酸", 410, "μmol/L", 202, 416),
      metric("exam-demo-2026-01", "creatinine", "肌酐", 86, "μmol/L", 45, 104),
      metric("exam-demo-2026-01", "weight", "体重", 67.8, "kg"),
    ],
  },
  {
    id: "exam-demo-2026-04",
    reportDate: "2026-04-22",
    title: "春季常规体检（演示）",
    hospital: "安心体检中心（虚拟）",
    doctor: "演示医生",
    fileName: "演示体检报告-2026-04.pdf",
    note: "本报告及全部数值均为虚拟演示数据。",
    metrics: [
      metric("exam-demo-2026-04", "systolic-bp", "收缩压", 135, "mmHg", 90, 139),
      metric("exam-demo-2026-04", "fasting-glucose", "空腹血糖", 5.6, "mmol/L", 3.9, 6.1),
      metric("exam-demo-2026-04", "total-cholesterol", "总胆固醇", 4.9, "mmol/L", 3, 5.2),
      metric("exam-demo-2026-04", "uric-acid", "尿酸", 398, "μmol/L", 202, 416),
      metric("exam-demo-2026-04", "creatinine", "肌酐", 82, "μmol/L", 45, 104),
      metric("exam-demo-2026-04", "weight", "体重", 67.2, "kg"),
    ],
  },
  {
    id: "exam-demo-2026-07",
    reportDate: "2026-07-18",
    title: "夏季复查（演示）",
    hospital: "安心体检中心（虚拟）",
    doctor: "演示医生",
    fileName: "演示体检报告-2026-07.pdf",
    note: "本报告及全部数值均为虚拟演示数据。",
    metrics: [
      metric("exam-demo-2026-07", "systolic-bp", "收缩压", 132, "mmHg", 90, 139),
      metric("exam-demo-2026-07", "fasting-glucose", "空腹血糖", 5.4, "mmol/L", 3.9, 6.1),
      metric("exam-demo-2026-07", "total-cholesterol", "总胆固醇", 4.8, "mmol/L", 3, 5.2),
      metric("exam-demo-2026-07", "uric-acid", "尿酸", 390, "μmol/L", 202, 416),
      metric("exam-demo-2026-07", "creatinine", "肌酐", 84, "μmol/L", 45, 104),
      metric("exam-demo-2026-07", "weight", "体重", 66.9, "kg"),
    ],
  },
];

const examinationReports = examinationSeeds.reduce<ExaminationReport[]>(
  (reports, seed) => {
    const report: ExaminationReport = {
      ...seed,
      analysis: buildExaminationAnalysis(seed, reports),
      createdAt: now,
      updatedAt: now,
    };
    return [...reports, report];
  },
  [],
);

export const demoData: AppData = {
  healthRecords: [
    {
      id: "health-demo",
      date: today,
      time: "09:10",
      overall: "正常",
      spirit: "一般",
      sleep: "一般",
      pain: "无",
      painLocation: "",
      symptoms: ["轻微乏力"],
      note: "今天状态平稳。",
      createdAt: now,
      updatedAt: now,
    },
  ],
  diseases: [
    {
      id: "disease-demo",
      name: "高血压（演示）",
      diagnosisDate: "2024-03-12",
      status: "稳定",
      hospital: "安心医院（虚拟）",
      doctor: "陈医生（虚拟）",
      precautions: "按医生说明用药，定期复查。",
      note: "本条为虚拟演示数据。",
      createdAt: now,
      updatedAt: now,
    },
  ],
  medications: [
    {
      id: "med-demo",
      name: "降压药（演示）",
      dose: "1",
      unit: "片",
      method: "口服",
      times: ["08:00", "20:00"],
      startDate: today,
      endDate: "",
      mealRequirement: "饭后",
      purpose: "帮助控制血压",
      doctorInstructions: "遵照医生说明服用",
      note: "虚拟药品，请勿作为用药建议。",
      reminderEnabled: true,
      createdAt: now,
      updatedAt: now,
    },
  ],
  medicationLogs: [
    {
      id: "log-demo-morning",
      medicationId: "med-demo",
      date: today,
      scheduledTime: "08:00",
      status: "已服用",
      actualTime: "08:06",
    },
  ],
  memos: [
    {
      id: "memo-demo",
      title: "下午 3 点去医院复查",
      category: "看医生",
      date: today,
      time: "15:00",
      reminderEnabled: true,
      note: "带上检查资料。",
      completed: false,
      createdAt: now,
      updatedAt: now,
    },
  ],
  meals: [
    {
      id: "meal-breakfast",
      date: today,
      time: "07:30",
      mealType: "早餐",
      foods: "粥、鸡蛋",
      portion: "正常",
      waterMl: 200,
      note: "",
      createdAt: now,
      updatedAt: now,
    },
    {
      id: "meal-lunch",
      date: today,
      time: "12:20",
      mealType: "午餐",
      foods: "米饭、蔬菜、鱼",
      portion: "正常",
      waterMl: 250,
      note: "",
      createdAt: now,
      updatedAt: now,
    },
  ],
  examinationReports,
  notificationLogs: [],
  profile: {
    name: "安心用户",
    gender: "",
    birthDate: "",
    phone: "",
    emergencyName: "",
    emergencyPhone: "",
    bloodType: "",
    allergies: "",
    note: "",
  },
  settings: {
    largeText: false,
    notificationsEnabled: false,
    reminderSound: true,
    onboardingDone: false,
  },
};
