"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { demoData } from "./demo-data";
import type { AppData, UserSettings } from "./types";

const STORAGE_KEY = "anxin-health-demo-v1";

type AppStore = {
  data: AppData;
  ready: boolean;
  update: (recipe: (current: AppData) => AppData) => void;
  reset: () => void;
  exportData: () => void;
  updateSettings: (settings: Partial<UserSettings>) => void;
};

const StoreContext = createContext<AppStore | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<AppData>(demoData);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) {
          const parsed = JSON.parse(stored) as Partial<AppData>;
          setData({
            ...demoData,
            ...parsed,
            examinationReports:
              parsed.examinationReports ?? demoData.examinationReports,
          });
        }
      } catch {
        localStorage.removeItem(STORAGE_KEY);
      } finally {
        setReady(true);
      }
    }, 0);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (ready) localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, [data, ready]);

  const update = useCallback((recipe: (current: AppData) => AppData) => {
    setData((current) => recipe(current));
  }, []);

  const reset = useCallback(() => {
    setData(JSON.parse(JSON.stringify(demoData)) as AppData);
  }, []);

  const exportData = useCallback(() => {
    const blob = new Blob([JSON.stringify(data, null, 2)], {
      type: "application/json",
    });
    const anchor = document.createElement("a");
    anchor.href = URL.createObjectURL(blob);
    anchor.download = `安心健康助手数据-${new Date().toISOString().slice(0, 10)}.json`;
    anchor.click();
    URL.revokeObjectURL(anchor.href);
  }, [data]);

  const updateSettings = useCallback(
    (settings: Partial<UserSettings>) => {
      update((current) => ({
        ...current,
        settings: { ...current.settings, ...settings },
      }));
    },
    [update],
  );

  const value = useMemo(
    () => ({ data, ready, update, reset, exportData, updateSettings }),
    [data, ready, update, reset, exportData, updateSettings],
  );

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const store = useContext(StoreContext);
  if (!store) throw new Error("useStore 必须在 StoreProvider 内使用");
  return store;
}
