import type {
  ExaminationAnalysis,
  ExaminationAnalysisItem,
  ExaminationMetric,
  ExaminationReport,
} from "./types";

function findPreviousMetric(
  metric: ExaminationMetric,
  reportDate: string,
  previousReports: ExaminationReport[],
) {
  return previousReports
    .filter((report) => !report.deletedAt && report.reportDate < reportDate)
    .sort((a, b) => b.reportDate.localeCompare(a.reportDate))
    .flatMap((report) => report.metrics)
    .find((item) => item.key === metric.key || item.name === metric.name);
}

function analyzeMetric(
  metric: ExaminationMetric,
  reportDate: string,
  previousReports: ExaminationReport[],
): ExaminationAnalysisItem {
  const previous = findPreviousMetric(metric, reportDate, previousReports);
  const hasMin = Number.isFinite(metric.referenceMin);
  const hasMax = Number.isFinite(metric.referenceMax);
  const range =
    hasMin || hasMax
      ? `${hasMin ? metric.referenceMin : "未填写"} 至 ${
          hasMax ? metric.referenceMax : "未填写"
        } ${metric.unit}`
      : "未填写";
  const change =
    previous && Number.isFinite(previous.value)
      ? Number((metric.value - previous.value).toFixed(2))
      : undefined;

  let status: ExaminationAnalysisItem["status"] = "待核对";
  if (hasMin && metric.value < Number(metric.referenceMin)) {
    status = "低于参考范围";
  } else if (hasMax && metric.value > Number(metric.referenceMax)) {
    status = "高于参考范围";
  } else if (hasMin || hasMax) {
    status = "参考范围内";
  }

  const comparison =
    change === undefined
      ? "这是该指标的首次记录。"
      : change === 0
        ? `与上次相同，仍为 ${metric.value} ${metric.unit}。`
        : `比上次${change > 0 ? "增加" : "减少"} ${Math.abs(change)} ${metric.unit}。`;

  const suggestion =
    status === "参考范围内"
      ? "继续保留报告并按原有医嘱复查，不要仅凭一次结果自行改变用药。"
      : status === "待核对"
        ? "请从原报告补充参考范围，或在复诊时请医生结合年龄、性别和检查方法解释。"
        : "请携带原报告咨询医生，确认是否需要复查；不要自行停药、加药或改变剂量。";

  return {
    metricId: metric.id,
    metricName: metric.name,
    status,
    message: `${metric.name}为 ${metric.value} ${metric.unit}；报告参考范围：${range}。${comparison}`,
    suggestion,
    previousValue: previous?.value,
    change,
  };
}

export function buildExaminationAnalysis(
  report: Pick<ExaminationReport, "reportDate" | "metrics">,
  previousReports: ExaminationReport[],
): ExaminationAnalysis {
  const items = report.metrics.map((metric) =>
    analyzeMetric(metric, report.reportDate, previousReports),
  );
  const attentionCount = items.filter(
    (item) =>
      item.status === "高于参考范围" || item.status === "低于参考范围",
  ).length;
  const inRangeCount = items.filter(
    (item) => item.status === "参考范围内",
  ).length;
  const pendingCount = items.filter((item) => item.status === "待核对").length;

  const summary =
    attentionCount > 0
      ? `本次有 ${attentionCount} 项超出所填写的报告参考范围，建议携带原报告向医生核对。`
      : pendingCount > 0
        ? `本次已分析 ${items.length} 项，其中 ${pendingCount} 项缺少参考范围，需要补充或请医生核对。`
        : `本次录入的 ${items.length} 项均在所填写的报告参考范围内，请继续按医嘱定期复查。`;

  return {
    generatedAt: new Date().toISOString(),
    summary,
    inRangeCount,
    attentionCount,
    pendingCount,
    items,
  };
}

export function analysisTone(status: ExaminationAnalysisItem["status"]) {
  if (status === "参考范围内") return "success";
  if (status === "待核对") return "neutral";
  return "warning";
}
