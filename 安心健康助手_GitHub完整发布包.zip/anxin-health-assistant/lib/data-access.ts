import type {
  Disease,
  ExaminationReport,
  HealthRecord,
  MealRecord,
  Medication,
  MedicationLog,
  Memo,
  Profile,
  UserSettings,
} from "./types";

/**
 * 所有数据操作都通过统一接口进入，页面不直接依赖数据库。
 * 当前本地实现位于 StoreProvider；Supabase 适配器可按同一接口接入。
 */
export interface HealthDataRepository {
  listHealthRecords(userId: string): Promise<HealthRecord[]>;
  saveHealthRecord(userId: string, record: HealthRecord): Promise<void>;
  listDiseases(userId: string): Promise<Disease[]>;
  saveDisease(userId: string, disease: Disease): Promise<void>;
  listMedications(userId: string): Promise<Medication[]>;
  saveMedication(userId: string, medication: Medication): Promise<void>;
  listMedicationLogs(userId: string, date: string): Promise<MedicationLog[]>;
  saveMedicationLog(userId: string, log: MedicationLog): Promise<void>;
  listMemos(userId: string, date: string): Promise<Memo[]>;
  saveMemo(userId: string, memo: Memo): Promise<void>;
  listMeals(userId: string, date: string): Promise<MealRecord[]>;
  saveMeal(userId: string, meal: MealRecord): Promise<void>;
  listExaminationReports(userId: string): Promise<ExaminationReport[]>;
  saveExaminationReport(
    userId: string,
    report: ExaminationReport,
  ): Promise<void>;
  getProfile(userId: string): Promise<Profile>;
  saveProfile(userId: string, profile: Profile): Promise<void>;
  getSettings(userId: string): Promise<UserSettings>;
  saveSettings(userId: string, settings: UserSettings): Promise<void>;
}

export type ReminderChannel = "browser" | "sms" | "wechat" | "native";

export interface ReminderGateway {
  send(input: {
    userId: string;
    channel: ReminderChannel;
    title: string;
    body: string;
    deduplicationKey: string;
  }): Promise<{ accepted: boolean; providerMessageId?: string }>;
}
