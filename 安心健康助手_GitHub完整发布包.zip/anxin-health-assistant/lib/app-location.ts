declare global {
  interface Window {
    __ANXIN_STANDALONE__?: boolean;
  }
}

export function isStandaloneMode() {
  return (
    typeof window !== "undefined" &&
    (window.location.protocol === "file:" ||
      window.__ANXIN_STANDALONE__ === true)
  );
}

export function getAppPathname() {
  if (typeof window === "undefined") return "/";
  if (!isStandaloneMode()) return window.location.pathname;

  const route = window.location.hash.replace(/^#/, "") || "/";
  return route.split("?")[0] || "/";
}

export function getAppSearchParams() {
  if (typeof window === "undefined") return new URLSearchParams();
  if (!isStandaloneMode()) return new URLSearchParams(window.location.search);

  const route = window.location.hash.replace(/^#/, "");
  const queryIndex = route.indexOf("?");
  return new URLSearchParams(queryIndex >= 0 ? route.slice(queryIndex + 1) : "");
}
