export type ID = string;

export type HealthRecord = {
  id: ID;
  date: string;
  time: string;
  overall: "很好" | "正常" | "不太舒服" | "很不舒服";
  spirit: string;
  sleep: string;
  pain: string;
  painLocation: string;
  symptoms: string[];
  note: string;
  createdAt: string;
  updatedAt: string;
  deletedAt?: string;
};

export type Disease = {
  id: ID;
  name: string;
  diagnosisDate: string;
  status: "治疗中" | "稳定" | "需要复查" | "已结束";
  hospital: string;
  doctor: string;
  precautions: string;
  note: string;
  createdAt: string;
  updatedAt: string;
  deletedAt?: string;
};

export type Medication = {
  id: ID;
  name: string;
  dose: string;
  unit: string;
  method: string;
  times: string[];
  startDate: string;
  endDate: string;
  mealRequirement: string;
  purpose: string;
  doctorInstructions: string;
  note: string;
  reminderEnabled: boolean;
  createdAt: string;
  updatedAt: string;
  deletedAt?: string;
};

export type MedicationLog = {
  id: ID;
  medicationId: ID;
  date: string;
  scheduledTime: string;
  status: "待服用" | "已服用" | "已跳过" | "已漏服";
  actualTime?: string;
  snoozeUntil?: string;
};

export type Memo = {
  id: ID;
  title: string;
  category: string;
  date: string;
  time: string;
  reminderEnabled: boolean;
  note: string;
  completed: boolean;
  createdAt: string;
  updatedAt: string;
  deletedAt?: string;
};

export type MealRecord = {
  id: ID;
  date: string;
  time: string;
  mealType: "早餐" | "午餐" | "晚餐" | "加餐" | "饮水";
  foods: string;
  portion: string;
  waterMl: number;
  note: string;
  photoName?: string;
  createdAt: string;
  updatedAt: string;
  deletedAt?: string;
};

export type ExaminationMetric = {
  id: ID;
  key: string;
  name: string;
  value: number;
  unit: string;
  referenceMin?: number;
  referenceMax?: number;
};

export type ExaminationAnalysisItem = {
  metricId: ID;
  metricName: string;
  status: "参考范围内" | "高于参考范围" | "低于参考范围" | "待核对";
  message: string;
  suggestion: string;
  previousValue?: number;
  change?: number;
};

export type ExaminationAnalysis = {
  generatedAt: string;
  summary: string;
  inRangeCount: number;
  attentionCount: number;
  pendingCount: number;
  items: ExaminationAnalysisItem[];
};

export type ExaminationReport = {
  id: ID;
  reportDate: string;
  title: string;
  hospital: string;
  doctor: string;
  fileName?: string;
  note: string;
  metrics: ExaminationMetric[];
  analysis: ExaminationAnalysis;
  createdAt: string;
  updatedAt: string;
  deletedAt?: string;
};

export type Profile = {
  name: string;
  gender: string;
  birthDate: string;
  phone: string;
  emergencyName: string;
  emergencyPhone: string;
  bloodType: string;
  allergies: string;
  note: string;
};

export type UserSettings = {
  largeText: boolean;
  notificationsEnabled: boolean;
  reminderSound: boolean;
  onboardingDone: boolean;
};

export type AppData = {
  healthRecords: HealthRecord[];
  diseases: Disease[];
  medications: Medication[];
  medicationLogs: MedicationLog[];
  memos: Memo[];
  meals: MealRecord[];
  examinationReports: ExaminationReport[];
  notificationLogs: string[];
  profile: Profile;
  settings: UserSettings;
};
