"use client";

import {
  Bell,
  CalendarDays,
  Home,
  Menu,
  ShieldCheck,
  Soup,
  Stethoscope,
  UserRound,
  X,
  type LucideIcon,
} from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { useStore } from "@/lib/store";
import { isoDate, timeNow } from "@/lib/date";
import { isStandaloneMode } from "@/lib/app-location";
import { Button, useToast } from "./ui";

const nav: { href: string; label: string; icon: LucideIcon }[] = [
  { href: "/home", label: "首页", icon: Home },
  { href: "/health", label: "健康", icon: Stethoscope },
  { href: "/medications/today", label: "用药", icon: CalendarDays },
  { href: "/meals", label: "饮食", icon: Soup },
  { href: "/profile", label: "我的", icon: UserRound },
];

export function navigate(href: string) {
  if (isStandaloneMode()) {
    window.location.hash = href;
    window.scrollTo({ top: 0, behavior: "auto" });
    return;
  }
  window.history.pushState({}, "", href);
  window.dispatchEvent(new PopStateEvent("popstate"));
  window.scrollTo({ top: 0, behavior: "auto" });
}

export function AppShell({
  children,
  pathname,
}: {
  children: ReactNode;
  pathname: string;
}) {
  const { data, update, updateSettings } = useStore();
  const { showToast } = useToast();
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeReminder, setActiveReminder] = useState<{
    key: string;
    medicationId: string;
    name: string;
    dose: string;
    requirement: string;
    scheduledTime: string;
  } | null>(null);

  useEffect(() => {
    document.documentElement.dataset.fontSize = data.settings.largeText
      ? "large"
      : "standard";
  }, [data.settings.largeText]);

  useEffect(() => {
    if (!isStandaloneMode() && "serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }
  }, []);

  useEffect(() => {
    const check = () => {
      const today = isoDate();
      const current = timeNow();
      for (const medication of data.medications.filter(
        (item) => !item.deletedAt && item.reminderEnabled,
      )) {
        for (const scheduledTime of medication.times) {
          const key = `${today}:${medication.id}:${scheduledTime}`;
          const taskLog = data.medicationLogs.find(
            (log) =>
              log.medicationId === medication.id &&
              log.date === today &&
              log.scheduledTime === scheduledTime,
          );
          const alreadyHandled =
            Boolean(taskLog) && taskLog?.status !== "待服用";
          const stillSnoozed =
            taskLog?.snoozeUntil &&
            new Date(taskLog.snoozeUntil).getTime() > Date.now();
          if (
            scheduledTime <= current &&
            !data.notificationLogs.includes(key) &&
            !alreadyHandled &&
            !stillSnoozed
          ) {
            const reminder = {
              key,
              medicationId: medication.id,
              name: medication.name,
              dose: `${medication.dose} ${medication.unit}`,
              requirement: medication.mealRequirement,
              scheduledTime,
            };
            setActiveReminder(reminder);
            if (
              data.settings.notificationsEnabled &&
              "Notification" in window &&
              Notification.permission === "granted"
            ) {
              new Notification(`该吃药了：${medication.name}`, {
                body: `${medication.dose} ${medication.unit}，${medication.mealRequirement}服用。`,
                icon: "/icon-192.png",
                tag: key,
              });
            }
            update((currentData) => ({
              ...currentData,
              notificationLogs: [...currentData.notificationLogs, key],
            }));
            return;
          }
        }
      }
    };
    check();
    const timer = window.setInterval(check, 30_000);
    return () => window.clearInterval(timer);
  }, [
    data.medications,
    data.medicationLogs,
    data.notificationLogs,
    data.settings.notificationsEnabled,
    update,
  ]);

  useEffect(() => {
    const handler = (event: MouseEvent) => {
      const anchor = (event.target as HTMLElement).closest<HTMLAnchorElement>(
        "a[data-nav]",
      );
      if (!anchor || event.ctrlKey || event.metaKey || event.shiftKey) return;
      event.preventDefault();
      navigate(anchor.getAttribute("href") || "/home");
      setMenuOpen(false);
    };
    document.addEventListener("click", handler);
    return () => document.removeEventListener("click", handler);
  }, []);

  const logMedication = (status: "已服用" | "已跳过") => {
    if (!activeReminder) return;
    update((current) => ({
      ...current,
      medicationLogs: [
        ...current.medicationLogs.filter(
          (log) =>
            !(
              log.medicationId === activeReminder.medicationId &&
              log.date === isoDate() &&
              log.scheduledTime === activeReminder.scheduledTime
            ),
        ),
        {
          id: activeReminder.key,
          medicationId: activeReminder.medicationId,
          date: isoDate(),
          scheduledTime: activeReminder.scheduledTime,
          status,
          actualTime: status === "已服用" ? timeNow() : undefined,
        },
      ],
    }));
    showToast(status === "已服用" ? "已记录服药时间" : "已跳过本次服药");
    setActiveReminder(null);
  };

  return (
    <div className="app-shell">
      <aside className={`sidebar ${menuOpen ? "sidebar-open" : ""}`}>
        <div className="brand">
          <span className="brand-mark">
            <ShieldCheck aria-hidden="true" />
          </span>
          <span>
            <strong>安心健康助手</strong>
            <small>每天记一点，健康更安心</small>
          </span>
          <button
            className="sidebar-close"
            aria-label="关闭菜单"
            onClick={() => setMenuOpen(false)}
          >
            <X aria-hidden="true" />
          </button>
        </div>
        <nav className="desktop-nav" aria-label="主要导航">
          {nav.map((item) => {
            const Icon = item.icon;
            const active =
              pathname === item.href ||
              (item.href !== "/home" && pathname.startsWith(item.href));
            return (
              <a
                href={item.href}
                data-nav
                key={item.href}
                className={active ? "nav-active" : ""}
                aria-current={active ? "page" : undefined}
              >
                <Icon aria-hidden="true" />
                <span>{item.label}</span>
              </a>
            );
          })}
        </nav>
        <div className="sidebar-note">
          <ShieldCheck aria-hidden="true" />
          <p>演示数据仅保存在此浏览器。清除浏览器数据后，记录可能丢失。</p>
        </div>
      </aside>

      <div className="content-column">
        <div className="mobile-topbar">
          <button aria-label="打开菜单" onClick={() => setMenuOpen(true)}>
            <Menu aria-hidden="true" />
          </button>
          <strong>安心健康助手</strong>
          <button
            aria-label={data.settings.largeText ? "切换为标准字体" : "切换为大字体"}
            onClick={() =>
              updateSettings({ largeText: !data.settings.largeText })
            }
          >
            <span className="font-toggle-icon" aria-hidden="true">
              A
            </span>
          </button>
        </div>
        <main className="main-content" id="main-content">
          {children}
        </main>
        <footer className="app-footer">
          <p>
            本应用用于帮助用户记录个人健康信息，不提供医学诊断。如身体不适，请及时咨询专业医生。
          </p>
          <a href="/privacy" data-nav>
            隐私政策
          </a>
          <a href="/help" data-nav>
            帮助说明
          </a>
        </footer>
      </div>

      <nav className="bottom-nav" aria-label="主要导航">
        {nav.map((item) => {
          const Icon = item.icon;
          const active =
            pathname === item.href ||
            (item.href !== "/home" && pathname.startsWith(item.href));
          return (
            <a
              href={item.href}
              data-nav
              key={item.href}
              className={active ? "nav-active" : ""}
              aria-current={active ? "page" : undefined}
            >
              <Icon aria-hidden="true" />
              <span>{item.label}</span>
            </a>
          );
        })}
      </nav>

      {menuOpen ? (
        <button
          className="menu-backdrop"
          aria-label="关闭菜单"
          onClick={() => setMenuOpen(false)}
        />
      ) : null}

      {activeReminder ? (
        <div className="reminder-banner" role="alert">
          <div className="reminder-icon">
            <Bell aria-hidden="true" />
          </div>
          <div>
            <strong>该吃药了：{activeReminder.name}</strong>
            <p>
              {activeReminder.dose}，{activeReminder.requirement}服用。
            </p>
            <div className="reminder-actions">
              <Button variant="success" onClick={() => logMedication("已服用")}>
                已服用
              </Button>
              <Button
                variant="secondary"
                onClick={() => {
                  const snoozeUntil = new Date(Date.now() + 10 * 60_000).toISOString();
                  update((current) => ({
                    ...current,
                    notificationLogs: current.notificationLogs.filter(
                      (item) => item !== activeReminder.key,
                    ),
                    medicationLogs: [
                      ...current.medicationLogs.filter(
                        (log) =>
                          !(
                            log.medicationId === activeReminder.medicationId &&
                            log.date === isoDate() &&
                            log.scheduledTime === activeReminder.scheduledTime
                          ),
                      ),
                      {
                        id: activeReminder.key,
                        medicationId: activeReminder.medicationId,
                        date: isoDate(),
                        scheduledTime: activeReminder.scheduledTime,
                        status: "待服用",
                        snoozeUntil,
                      },
                    ],
                  }));
                  showToast("将在 10 分钟后再次在应用内提醒");
                  setActiveReminder(null);
                }}
              >
                10 分钟后提醒
              </Button>
              <Button variant="quiet" onClick={() => logMedication("已跳过")}>
                跳过本次
              </Button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
