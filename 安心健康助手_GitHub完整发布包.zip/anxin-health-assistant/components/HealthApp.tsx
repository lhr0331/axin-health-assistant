"use client";

import { Home, SearchX } from "lucide-react";
import { useEffect, useState } from "react";
import { AppShell, navigate } from "./AppShell";
import { LoadingState, Button, ToastProvider } from "./ui";
import { StoreProvider, useStore } from "@/lib/store";
import { Dashboard } from "@/features/Dashboard";
import {
  Diseases,
  HealthForm,
  HealthHistory,
  HealthHub,
} from "@/features/Health";
import {
  MedicationForm,
  MedicationHistory,
  MedicationList,
  TodayMedication,
} from "@/features/Medications";
import { MealForm, Meals, MemoForm, Memos } from "@/features/Daily";
import {
  ExaminationReportDetail,
  ExaminationReportForm,
  ExaminationReports,
} from "@/features/ExamReports";
import {
  Help,
  NotificationSettings,
  Privacy,
  Profile,
  ProfileForm,
  SettingsPage,
} from "@/features/Account";
import { Login, Onboarding } from "@/features/Entry";
import { getAppPathname } from "@/lib/app-location";

function NotFound() {
  return (
    <div className="empty-state not-found">
      <SearchX size={52} aria-hidden="true" />
      <h1>没有找到这个页面</h1>
      <p>链接可能已变化，你可以回到首页继续使用。</p>
      <Button icon={Home} onClick={() => navigate("/home")}>
        返回首页
      </Button>
    </div>
  );
}

function Router() {
  const { ready } = useStore();
  const [pathname, setPathname] = useState("/");

  useEffect(() => {
    const sync = () => setPathname(getAppPathname());
    sync();
    window.addEventListener("popstate", sync);
    window.addEventListener("hashchange", sync);
    return () => {
      window.removeEventListener("popstate", sync);
      window.removeEventListener("hashchange", sync);
    };
  }, []);

  if (!ready) return <LoadingState />;
  if (pathname === "/") return <Login />;
  if (pathname === "/onboarding") return <Onboarding />;

  let page;
  switch (pathname) {
    case "/home":
      page = <Dashboard />;
      break;
    case "/health":
      page = <HealthHub />;
      break;
    case "/health/add":
      page = <HealthForm />;
      break;
    case "/health/history":
      page = <HealthHistory />;
      break;
    case "/diseases":
    case "/diseases/detail":
      page = <Diseases />;
      break;
    case "/reports":
      page = <ExaminationReports />;
      break;
    case "/reports/add":
      page = <ExaminationReportForm />;
      break;
    case "/reports/detail":
      page = <ExaminationReportDetail />;
      break;
    case "/medications":
      page = <MedicationList />;
      break;
    case "/medications/add":
      page = <MedicationForm />;
      break;
    case "/medications/today":
      page = <TodayMedication />;
      break;
    case "/medications/history":
      page = <MedicationHistory />;
      break;
    case "/memos":
      page = <Memos />;
      break;
    case "/memos/add":
      page = <MemoForm />;
      break;
    case "/meals":
      page = <Meals />;
      break;
    case "/meals/add":
      page = <MealForm />;
      break;
    case "/profile":
      page = <Profile />;
      break;
    case "/profile/edit":
      page = <ProfileForm />;
      break;
    case "/settings":
      page = <SettingsPage />;
      break;
    case "/settings/notifications":
      page = <NotificationSettings />;
      break;
    case "/help":
      page = <Help />;
      break;
    case "/privacy":
      page = <Privacy />;
      break;
    default:
      page = <NotFound />;
  }

  return <AppShell pathname={pathname}>{page}</AppShell>;
}

export function HealthApp() {
  return (
    <StoreProvider>
      <ToastProvider>
        <Router />
      </ToastProvider>
    </StoreProvider>
  );
}
