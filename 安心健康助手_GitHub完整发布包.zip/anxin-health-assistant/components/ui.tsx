"use client";

import {
  AlertCircle,
  CheckCircle2,
  ChevronLeft,
  LoaderCircle,
  X,
  type LucideIcon,
} from "lucide-react";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ButtonHTMLAttributes,
  type InputHTMLAttributes,
  type ReactNode,
  type SelectHTMLAttributes,
  type TextareaHTMLAttributes,
} from "react";

export function Button({
  children,
  variant = "primary",
  icon: Icon,
  className = "",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "danger" | "success" | "quiet";
  icon?: LucideIcon;
}) {
  return (
    <button
      className={`button button-${variant} ${className}`}
      {...props}
    >
      {Icon ? <Icon aria-hidden="true" size={22} strokeWidth={2.3} /> : null}
      <span>{children}</span>
    </button>
  );
}

export function Card({
  children,
  className = "",
  as = "section",
}: {
  children: ReactNode;
  className?: string;
  as?: "section" | "article" | "div";
}) {
  const Tag = as;
  return <Tag className={`card ${className}`}>{children}</Tag>;
}

export function StatusBadge({
  status,
}: {
  status: string;
}) {
  const tone =
    status.includes("完成") ||
    status.includes("已服") ||
    status.includes("范围内") ||
    status === "稳定" ||
    status === "很好"
      ? "success"
      : status.includes("高于") ||
          status.includes("低于") ||
          status.includes("核对") ||
          status.includes("超出") ||
          status.includes("漏") ||
          status.includes("舒服") ||
          status === "治疗中"
        ? "danger"
        : status.includes("待") || status.includes("复查")
          ? "warning"
          : "neutral";
  return (
    <span className={`status status-${tone}`}>
      {tone === "success" ? (
        <CheckCircle2 size={17} aria-hidden="true" />
      ) : tone === "danger" ? (
        <AlertCircle size={17} aria-hidden="true" />
      ) : (
        <span aria-hidden="true">●</span>
      )}
      {status}
    </span>
  );
}

export function Field({
  label,
  hint,
  error,
  children,
}: {
  label: string;
  hint?: string;
  error?: string;
  children: ReactNode;
}) {
  return (
    <label className="field">
      <span className="field-label">{label}</span>
      {hint ? <span className="field-hint">{hint}</span> : null}
      {children}
      {error ? (
        <span className="field-error" role="alert">
          <AlertCircle size={18} aria-hidden="true" />
          {error}
        </span>
      ) : null}
    </label>
  );
}

export function Input(props: InputHTMLAttributes<HTMLInputElement>) {
  return <input className="input" {...props} />;
}

export function Select(props: SelectHTMLAttributes<HTMLSelectElement>) {
  return <select className="input" {...props} />;
}

export function Textarea(props: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea className="input textarea" rows={4} {...props} />;
}

export function ChoiceGroup({
  options,
  value,
  onChange,
  multiple = false,
  ariaLabel,
}: {
  options: string[];
  value: string | string[];
  onChange: (value: string | string[]) => void;
  multiple?: boolean;
  ariaLabel: string;
}) {
  const selected = Array.isArray(value) ? value : [value];
  return (
    <div className="choice-grid" role="group" aria-label={ariaLabel}>
      {options.map((option) => (
        <button
          key={option}
          type="button"
          className={`choice ${selected.includes(option) ? "choice-selected" : ""}`}
          aria-pressed={selected.includes(option)}
          onClick={() => {
            if (!multiple) return onChange(option);
            onChange(
              selected.includes(option)
                ? selected.filter((item) => item !== option)
                : [...selected, option],
            );
          }}
        >
          {selected.includes(option) ? (
            <CheckCircle2 size={20} aria-hidden="true" />
          ) : null}
          {option}
        </button>
      ))}
    </div>
  );
}

export function EmptyState({
  icon: Icon = AlertCircle,
  title,
  description,
  action,
}: {
  icon?: LucideIcon;
  title: string;
  description: string;
  action?: ReactNode;
}) {
  return (
    <div className="empty-state">
      <Icon size={34} aria-hidden="true" />
      <h3>{title}</h3>
      <p>{description}</p>
      {action}
    </div>
  );
}

export function LoadingState() {
  return (
    <div className="loading-state" role="status">
      <LoaderCircle className="spin" size={28} aria-hidden="true" />
      <span>正在加载，请稍候</span>
    </div>
  );
}

export function PageHeader({
  title,
  description,
  backHref,
  action,
}: {
  title: string;
  description?: string;
  backHref?: string;
  action?: ReactNode;
}) {
  return (
    <header className="page-header">
      <div className="page-heading">
        {backHref ? (
          <a href={backHref} className="back-link" data-nav>
            <ChevronLeft aria-hidden="true" />
            返回
          </a>
        ) : null}
        <h1>{title}</h1>
        {description ? <p>{description}</p> : null}
      </div>
      {action}
    </header>
  );
}

export function Progress({
  value,
  max,
  label,
}: {
  value: number;
  max: number;
  label: string;
}) {
  const percent = max ? Math.round((value / max) * 100) : 0;
  return (
    <div className="progress-wrap">
      <div className="progress-copy">
        <span>{label}</span>
        <strong>{percent}%</strong>
      </div>
      <div
        className="progress"
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={max}
        aria-valuenow={value}
        aria-label={label}
      >
        <span style={{ width: `${percent}%` }} />
      </div>
    </div>
  );
}

type ToastItem = { id: number; message: string; tone: "success" | "error" };
const ToastContext = createContext<{
  showToast: (message: string, tone?: "success" | "error") => void;
} | null>(null);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const showToast = useCallback(
    (message: string, tone: "success" | "error" = "success") => {
      const id = Date.now();
      setToasts((items) => [...items, { id, message, tone }]);
      window.setTimeout(
        () => setToasts((items) => items.filter((item) => item.id !== id)),
        3500,
      );
    },
    [],
  );

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <div className="toast-region" aria-live="polite" aria-atomic="true">
        {toasts.map((toast) => (
          <div key={toast.id} className={`toast toast-${toast.tone}`}>
            {toast.tone === "success" ? (
              <CheckCircle2 aria-hidden="true" />
            ) : (
              <AlertCircle aria-hidden="true" />
            )}
            <span>{toast.message}</span>
            <button
              aria-label="关闭提示"
              onClick={() =>
                setToasts((items) =>
                  items.filter((item) => item.id !== toast.id),
                )
              }
            >
              <X aria-hidden="true" />
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const context = useContext(ToastContext);
  if (!context) throw new Error("useToast 必须在 ToastProvider 内使用");
  return context;
}

export function ConfirmDialog({
  open,
  title,
  description,
  confirmText = "确认删除",
  onConfirm,
  onCancel,
}: {
  open: boolean;
  title: string;
  description: string;
  confirmText?: string;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  useEffect(() => {
    if (!open) return;
    const handler = (event: KeyboardEvent) => {
      if (event.key === "Escape") onCancel();
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [open, onCancel]);

  if (!open) return null;
  return (
    <div className="dialog-backdrop" role="presentation" onMouseDown={onCancel}>
      <div
        className="dialog"
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="dialog-title"
        onMouseDown={(event) => event.stopPropagation()}
      >
        <AlertCircle className="dialog-icon" size={36} aria-hidden="true" />
        <h2 id="dialog-title">{title}</h2>
        <p>{description}</p>
        <div className="dialog-actions">
          <Button variant="secondary" onClick={onCancel}>
            取消
          </Button>
          <Button variant="danger" onClick={onConfirm}>
            {confirmText}
          </Button>
        </div>
      </div>
    </div>
  );
}
