import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { HealthApp } from "@/components/HealthApp";
import "@/app/globals.css";

const root = document.getElementById("root");

if (!root) {
  throw new Error("无法启动安心健康助手：缺少页面根节点。");
}

createRoot(root).render(
  <StrictMode>
    <HealthApp />
  </StrictMode>,
);
